package GUI;

import Controller.Controller;
import model.Biglietto;
import model.Cliente;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The type Cli interface.
 */
public class CliInterface {
    private JPanel cliInterface;
    private JButton visualizzaCorsa;
    private JButton annullaBigliettoButton;
    private JButton logOutButton;
    private JButton visualizzaSpecificheButton;
    private JComboBox comoBoxBiglietti;
    private JList listaSpecificheBiglietto;
    private JLabel labelBiglietti;
    private JButton modificaDatiPersonaliButton;

    /**
     * The Frame.
     */
    public JFrame frame;

    /**
     * Instantiates a new Cli interface.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public CliInterface(JFrame frameChiamante, Controller controller) {
        frame = new JFrame("CliInterface");
        frame.setContentPane(cliInterface);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        //il metodo getBiglietti prende i biglietti dell'utente che ha fatto il login.

        controller.getBiglietti();

        //inseriamo i biglietti trovati all'intenro della combobox

        comoBoxBiglietti.addItem("Nessun Biglietto Selezionato");
        for(Biglietto biglietti : controller.getAcquisti()){
        comoBoxBiglietti.addItem("Biglietto : "+biglietti.getId_Biglietto()+" ID Corsa : "+biglietti.getCorsa().getId_corsa()+" Il "+biglietti.getCorsa().getData()+" Per "+biglietti.getCorsa().getPorto_A());
        }

       visualizzaSpecificheButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               DefaultListModel listModel = new DefaultListModel();
               listaSpecificheBiglietto.setModel(listModel);

               //mostriamo a schermo le specifiche del biglietto selezionato

                    if(!comoBoxBiglietti.getSelectedItem().toString().equals("Nessun Biglietto Selezionato")) {
                        for (int i=0;i<controller.GrandeZZAArreyBiglietti();i++) {
                            if (Integer.toString(controller.getId_Biglietto(i)).equals(comoBoxBiglietti.getSelectedItem().toString().substring(12, comoBoxBiglietti.getSelectedItem().toString().indexOf("ID")).trim())) {

                                listModel.addElement("ID Biglietto :" + controller.getId_corsaBiglietto(i));
                                listModel.addElement("ID Corsa:" + controller.getId_corsaBiglietto(i));
                                listModel.addElement("Data di Partenza : " + controller.getDataBiglietto(i));
                                listModel.addElement("Porto di Partenza : " + controller.getPorto_PBiglietto(i));
                                listModel.addElement("Porto di Arrivo : " + controller.getPorto_ABiglietto(i));
                                listModel.addElement("Orario di Partenza : " + controller.getOrario_PBiglietto(i));
                                listModel.addElement("Orario d'Arrivo : " + controller.getOrario_ABiglietto(i));
                                if (controller.getRitardoBiglietto(i) > 0) {
                                    listModel.addElement("Ritardo Segnalato : " + controller.getRitardoBiglietto(i));
                                }
                                listModel.addElement("Numero Bagagli : " + controller.getBagagli(i));
                                if (controller.getNatanteBiglietto(i).equals("Traghetto")) {
                                    listModel.addElement("AutoVeicolo Secelzionato : " + controller.getTipoAutoveicolo(i));
                                }
                                listModel.addElement("Disabilita :" +controller.isDisabilita(i));
                            }
                        }
                    }
           }
       });


    annullaBigliettoButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

            //eliminiamo il biglietto selezionato

            if(!comoBoxBiglietti.getSelectedItem().toString().equals("Nessun Biglietto Selezionato")){
                Object[] opzioi = {"Elimina", "Torna indietro"};
                JOptionPane.setDefaultLocale(null);
                int opzioni = JOptionPane.showOptionDialog(cliInterface, "Sei sicuro di cancellare il tuo Biglietto", "Selzione ", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, UIManager.getIcon("OptionPane.warningIcon"), opzioi, opzioi[0]);
                if (opzioni == 0) {
                    for (int i=0;i<controller.GrandeZZAArreyBiglietti();i++) {
                        if (Integer.toString(controller.getId_Biglietto(i)).equals(comoBoxBiglietti.getSelectedItem().toString().substring(12, comoBoxBiglietti.getSelectedItem().toString().indexOf("ID")).trim())) {
                            JOptionPane.showMessageDialog(null, "Biglietto eliminato");
                            controller.eliminaBigli(i);
                        }
                    }
                    comoBoxBiglietti.removeItem(comoBoxBiglietti.getSelectedItem());
                }
            }
        }
    });

    modificaDatiPersonaliButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            ModificaDatiCli modifica = new ModificaDatiCli(frame,controller);
            modifica.frame.setVisible(true);
            frame.setVisible(false);
        }
    });

        visualizzaCorsa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                comoBoxBiglietti.removeAllItems();
                controller.SvuotaArreyBiglietti();

                ListaCoreseCli lista = new ListaCoreseCli(frame,frameChiamante,controller);
                lista.frame.setVisible(true);
                frame.dispose();

            }
        });
        logOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameChiamante.setVisible(true);
                frame.dispose();

            }
        });
    }

}
