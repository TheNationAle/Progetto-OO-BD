package ImplementazioneDAOpostgresql;

import ConnessineDB.ConnessioneDB;
import DAO.DAOCli;
import model.*;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 * The type Implementazione dao clienti.
 */
public class ImplementazioneDAOClienti implements DAOCli {
    private Connection connection;

    /**
     * Instantiates a new Implementazione dao clienti.
     */
    public ImplementazioneDAOClienti() {
        try {
            this.connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException var2) {
            var2.printStackTrace();
        }

    }

    @Override
    public Cliente ControlloCredenzialiCli(Cliente C) {
        try {
            Statement ControllaCredenziali;
            ControllaCredenziali = connection.createStatement();
            ResultSet rs = ControllaCredenziali.executeQuery("SELECT * FROM cliente ");
            while (rs.next()) {
                if (rs.getString("email").equals(C.getEmail()) && rs.getString("passwordcli").equals(C.getPassword())) {

                    C.setNome(rs.getString("nome"));
                    C.setCongnome(rs.getString("cognome"));
                    C.setSex(rs.getString("sex"));
                    C.setDataN(rs.getDate("data_n").toLocalDate());

                    return C;
                }
            }
            return null;
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return null;
        }
    }

    @Override
    public String RegistraCliDb(Cliente cli) {
        try {
            PreparedStatement ControllaCredenziali;
            ControllaCredenziali = connection.prepareStatement("INSERT INTO cliente(email, passwordcli, nome, cognome, sex,data_n) VALUES (?, ?, ?, ?, ?,?)");
            ControllaCredenziali.setString(1, cli.getEmail());
            ControllaCredenziali.setString(2, cli.getPassword());
            ControllaCredenziali.setString(3, cli.getNome());
            ControllaCredenziali.setString(4, cli.getCongnome());
            ControllaCredenziali.setString(5, cli.getSex());
            ControllaCredenziali.setDate  (6, Date.valueOf(cli.getDataN()));
            ControllaCredenziali.executeUpdate();
            return "";
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
    }

    @Override
    public void CercaPortidb(ArrayList<Porto> porti) {
        try {
            Statement getPorti;
            getPorti = connection.createStatement();
            ResultSet rs = getPorti.executeQuery("SELECT * FROM porto ORDER BY nome");
            while (rs.next()) {

                porti.add(new Porto(rs.getString("nome"), rs.getString("comune"), rs.getString("coordinate")));
            }

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());

        }

    }

    @Override
    public String cercaCorse(ArrayList<Corsa> corsa, String portoP, String portoA, LocalDate d, LocalTime t, int prezzo) {
        try {
            PreparedStatement getCorse;
            getCorse = connection.prepareStatement("SELECT * FROM corsa WHERE partenza=? AND arrivo=? AND data BETWEEN ? AND ? AND cancellazione = false AND prezzo_i<=?");
            getCorse.setString(1, portoP);
            getCorse.setString(2, portoA);
            getCorse.setDate(3, Date.valueOf(d));
            getCorse.setDate(4, Date.valueOf(d.plusDays(1)));
            getCorse.setInt(5, prezzo);
            ResultSet rs = getCorse.executeQuery();


            while (rs.next()) {
                if ((d.isEqual(rs.getDate("data").toLocalDate()) && t.compareTo(rs.getTime("orariop").toLocalTime()) <= 0) ||
                        d.plusDays(1).isEqual(rs.getDate("data").toLocalDate()) && t.compareTo(rs.getTime("orariop").toLocalTime()) >= 0) {

                    PreparedStatement Natante;
                    Natante = connection.prepareStatement("SELECT * FROM natante WHERE id_natante = ?");
                    Natante.setInt(1, rs.getInt("id_natante"));
                    ResultSet rsNat = Natante.executeQuery();
                    rsNat.next();

                    PreparedStatement compagnia;
                    compagnia = connection.prepareStatement("SELECT * FROM compagnia WHERE  nome= ?");
                    compagnia.setString(1, rsNat.getString("compagnia"));
                    ResultSet rsComp = compagnia.executeQuery();
                    rsComp.next();

                    PreparedStatement Cadenza;
                    Cadenza = connection.prepareStatement("SELECT * FROM cadenza WHERE id_cadenza = ?");
                    Cadenza.setInt(1, rs.getInt("id_cadenza"));
                    ResultSet rsCad = Cadenza.executeQuery();
                    rsCad.next();

                    corsa.add(new Corsa(rs.getInt("id_corsa"), rs.getDate("data"), rs.getTime("orariop"),
                            rs.getTime("orarioa"), rs.getFloat("prezzo_i"), rs.getFloat("prezzo_r"), portoP, portoA,

                            new Natante(rsNat.getInt("id_natante"), rsNat.getInt("capienzap"),
                                    rsNat.getInt("capienzaa"), rsNat.getString("tipo"), rsNat.getString("nome"),
                                    new Compagnia(rsComp.getString("email"), rsComp.getString("telefono"), rsComp.getString("nome"),
                                            rsComp.getString("sitoweb"), rsComp.getString("social"), rsComp.getString("passwordcomp"), rsComp.getFloat("sovraprezzo_p"), rsComp.getFloat("sovraprezzo_b"))),

                            new Cadenza(rsCad.getInt("id_cadenza"), rsCad.getString("giorno"), rsCad.getDate("periodo_i"),
                                    rsCad.getDate("periodo_f")), rs.getInt("postirimasti_p"), rs.getInt("postirimasti_a"), rs.getInt("ritardo")));

                }

            }
            if (corsa.size() > 0) {
                return "Corse Trovate";
            } else {
                return "";
            }
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }

    }

    @Override
    public String cercaCorseS(ArrayList<Corsa> corsa, String portoP, String portoA, LocalDate d, LocalTime t) {
        try {
            PreparedStatement getPartenza;
            getPartenza = connection.prepareStatement("SELECT * FROM corsa WHERE partenza=? AND data BETWEEN ? AND ? AND cancellazione = false ");
            getPartenza.setString(1, portoP);
            getPartenza.setDate(2, Date.valueOf(d));
            getPartenza.setDate(3, Date.valueOf(d.plusDays(1)));
            ResultSet rs = getPartenza.executeQuery();

            while (rs.next()) {

                PreparedStatement getDestinazione;
                getDestinazione = connection.prepareStatement("SELECT * FROM corsa WHERE partenza=? AND arrivo = ? AND orariop BETWEEN ? AND ? AND data BETWEEN ? AND ? AND partenza<>? AND cancellazione = false");
                getDestinazione.setString(1, rs.getString("arrivo"));
                getDestinazione.setString(2, portoA);
                getDestinazione.setTime(3, Time.valueOf(rs.getTime("orarioa").toLocalTime().plusMinutes(15 + rs.getInt("ritardo"))));
                getDestinazione.setTime(4, Time.valueOf(rs.getTime("orarioa").toLocalTime().plusHours(3)));
                getDestinazione.setDate(5, Date.valueOf(d));
                getDestinazione.setDate(6, Date.valueOf(d.plusDays(1)));
                getDestinazione.setString(7, rs.getString("partenza"));
                ResultSet rsSca = getDestinazione.executeQuery();

                while (rsSca.next()) {
                    if ((d.isEqual(rs.getDate("data").toLocalDate()) && t.compareTo(rs.getTime("orariop").toLocalTime()) <= 0) ||
                            d.plusDays(1).isEqual(rs.getDate("data").toLocalDate()) && t.compareTo(rs.getTime("orariop").toLocalTime()) >= 0) {


                        PreparedStatement Natante;
                        Natante = connection.prepareStatement("SELECT * FROM natante WHERE id_natante = ?");
                        Natante.setInt(1, rs.getInt("id_natante"));
                        ResultSet rsNat = Natante.executeQuery();
                        rsNat.next();

                        PreparedStatement Cadenza;
                        Cadenza = connection.prepareStatement("SELECT * FROM cadenza WHERE id_cadenza = ?");
                        Cadenza.setInt(1, rs.getInt("id_cadenza"));
                        ResultSet rsCad = Cadenza.executeQuery();
                        rsCad.next();

                        PreparedStatement compagnia;
                        compagnia = connection.prepareStatement("SELECT * FROM compagnia WHERE  nome= ?");
                        compagnia.setString(1, rsNat.getString("compagnia"));
                        ResultSet rsComp = compagnia.executeQuery();
                        rsComp.next();

                        corsa.add(new Corsa(rs.getInt("id_corsa"), rs.getDate("data"), rs.getTime("orariop"),
                                rs.getTime("orarioa"), rs.getFloat("prezzo_i"), rs.getFloat("prezzo_r"), portoP, rs.getString("arrivo"),


                                new Natante(rsNat.getInt("id_natante"), rsNat.getInt("capienzap"),
                                        rsNat.getInt("capienzaa"), rsNat.getString("tipo"), rsNat.getString("nome"),
                                        new Compagnia(rsComp.getString("email"), rsComp.getString("telefono"), rsComp.getString("nome"),
                                                rsComp.getString("sitoweb"), rsComp.getString("social"), rsComp.getString("passwordcomp"),
                                                rsComp.getFloat("sovraprezzo_p"), rsComp.getFloat("sovraprezzo_b"))),

                                new Cadenza(rsCad.getInt("id_cadenza"), rsCad.getString("giorno"), rsCad.getDate("periodo_i"), rsCad.getDate("periodo_f")),
                                rs.getInt("postirimasti_p"), rs.getInt("postirimasti_a"), rs.getInt("ritardo")));


                        PreparedStatement natanteS;
                        natanteS = connection.prepareStatement("SELECT * FROM natante WHERE id_natante = ?");
                        natanteS.setInt(1, rsSca.getInt("id_natante"));
                        ResultSet rsNatS = natanteS.executeQuery();
                        rsNatS.next();

                        PreparedStatement compagnia2;
                        compagnia2 = connection.prepareStatement("SELECT * FROM compagnia WHERE  nome= ?");
                        compagnia2.setString(1, rsNatS.getString("compagnia"));
                        ResultSet rsComp2 = compagnia2.executeQuery();
                        rsComp2.next();


                        PreparedStatement CadenzaS;
                        CadenzaS = connection.prepareStatement("SELECT * FROM cadenza WHERE id_cadenza = ?");
                        CadenzaS.setInt(1, rsSca.getInt("id_cadenza"));
                        ResultSet rsCadS = Cadenza.executeQuery();
                        rsCadS.next();

                        corsa.add(new Corsa(rsSca.getInt("id_corsa"), rsSca.getDate("data"), rsSca.getTime("orariop"),
                                rsSca.getTime("orarioa"), rsSca.getFloat("prezzo_i"), rsSca.getFloat("prezzo_r"), rsSca.getString("partenza"), portoA,

                                new Natante(rsNatS.getInt("id_natante"), rsNatS.getInt("capienzap"),
                                        rsNatS.getInt("capienzaa"), rsNatS.getString("tipo"), rsNatS.getString("nome"), new Compagnia(rsComp2.getString("email"), rsComp2.getString("telefono"), rsComp2.getString("nome"),
                                        rsComp2.getString("sitoweb"), rsComp2.getString("social"), rsComp2.getString("passwordcomp"),
                                        rsComp2.getFloat("sovraprezzo_p"), rsComp2.getFloat("sovraprezzo_b"))),

                                new Cadenza(rsCadS.getInt("id_cadenza"), rsCadS.getString("giorno"), rsCadS.getDate("periodo_i"), rsCadS.getDate("periodo_f")), rsSca.getInt("postirimasti_p"), rsSca.getInt("postirimasti_a"), rsSca.getInt("ritardo")));

                    }

                }


            }
            if (corsa.isEmpty()) {
                return "";
            } else {
                return "Corse Trovate";
            }

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());

            return e.getMessage();
        }
    }

    @Override
    public void autoVeicoliCompinCorsa(Compagnia comp) {
        try {
            PreparedStatement autoVeicoliAcettti;
            autoVeicoliAcettti = connection.prepareStatement("SELECT * FROM autoveicolo WHERE nome_compagnia = ?");
            autoVeicoliAcettti.setString(1, comp.getNome());
            ResultSet rsAT = autoVeicoliAcettti.executeQuery();

            while (rsAT.next()) {

                comp.getElencoAutoveicoli().add(new Autoveicolo(rsAT.getString("tipo"), rsAT.getFloat("sovraprezzo_a"), rsAT.getInt("dimensione"), comp));

            }
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }



    @Override
    public String aggiungiBiglietto(Cliente cli, Corsa cor, int bag, String autoveicolo, boolean disa, boolean preno) {
        try {
            PreparedStatement insericiBiglietto;
            insericiBiglietto = connection.prepareStatement("INSERT INTO biglietto (email, id_corsa, prenotazione, disbilita, bagagli, tipoautoveicolo) VALUES ( ?, ?, ?, ?, ?, ?)");
            insericiBiglietto.setString(1, cli.getEmail());
            insericiBiglietto.setInt(2, cor.getId_corsa());
            insericiBiglietto.setBoolean(3, preno);
            insericiBiglietto.setBoolean(4, disa);
            insericiBiglietto.setInt(5, bag);
            insericiBiglietto.setString(6, autoveicolo);
            insericiBiglietto.executeUpdate();

            return "";
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
    }

    @Override
    public void getBigliettiPrenotati(Cliente cli) {
        try {
            PreparedStatement getBiglietti;
            getBiglietti = connection.prepareStatement("SELECT * FROM biglietto WHERE email=?");
            getBiglietti.setString(1, cli.getEmail());
            ResultSet rs = getBiglietti.executeQuery();
            while (rs.next()) {

                PreparedStatement getCorsa;
                getCorsa = connection.prepareStatement("SELECT * FROM corsa WHERE id_corsa=?");
                getCorsa.setInt(1, rs.getInt("id_corsa"));
                ResultSet rsCors = getCorsa.executeQuery();
                rsCors.next();

                PreparedStatement natanteS;
                natanteS = connection.prepareStatement("SELECT * FROM natante WHERE id_natante = ?");
                natanteS.setInt(1, rsCors.getInt("id_natante"));
                ResultSet rsNat = natanteS.executeQuery();
                rsNat.next();

                PreparedStatement compagnia;
                compagnia = connection.prepareStatement("SELECT * FROM compagnia WHERE  nome= ?");
                compagnia.setString(1, rsNat.getString("compagnia"));
                ResultSet rsComp = compagnia.executeQuery();
                rsComp.next();

                cli.getAcquisti().add(new Biglietto(rs.getInt("id_biglietto"), rs.getBoolean("prenotazione"), rs.getInt("bagagli"), rs.getString("tipoautoveicolo"), rs.getBoolean("disbilita"),
                        new Corsa(rsCors.getInt("id_corsa"), rsCors.getDate("data"), rsCors.getTime("orariop"),
                                rsCors.getTime("orarioa"), rsCors.getFloat("prezzo_i"), rsCors.getFloat("prezzo_r"), rsCors.getString("partenza"), rsCors.getString("arrivo"),
                                new Natante(rsNat.getInt("id_natante"), rsNat.getInt("capienzap"),
                                        rsNat.getInt("capienzaa"), rsNat.getString("tipo"), rsNat.getString("nome"),new Compagnia(rsComp.getString("email"),rsComp.getString("telefono"),rsComp.getString("nome"),
                                        rsComp.getString("sitoweb"),rsComp.getString("social"),rsComp.getString("passwordcomp"),
                                        rsComp.getFloat("sovraprezzo_p"),rsComp.getFloat("sovraprezzo_b")))), cli));
            }

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());

        }
    }

    @Override
    public void eliminaBiglietti(Biglietto bigli) {

            try {
                PreparedStatement eliminaBig;
                eliminaBig = connection.prepareStatement("DELETE FROM biglietto WHERE id_biglietto = ?");
                eliminaBig.setInt(1, bigli.getId_Biglietto());
                eliminaBig.executeUpdate();

            } catch (Exception e) {
                System.out.println("Errore: " + e.getMessage());

            }
    }

    @Override
    public String updateCli(String nome, String cognome, LocalDate localDate, String sex, String pass, String email) {
        try {
            PreparedStatement updateC;
            updateC = connection.prepareStatement("UPDATE cliente SET passwordcli=?, nome=?, cognome=?, sex=?, data_n=? WHERE email=? ;");
            updateC.setString(1, pass);
            updateC.setString(2, nome);
            updateC.setString(3, cognome);
            updateC.setString(4, sex);
            updateC.setDate(5, Date.valueOf(localDate));
            updateC.setString(6,email);
            updateC.executeUpdate();
            return "";
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());

            return e.getMessage();
        }

    }
}
