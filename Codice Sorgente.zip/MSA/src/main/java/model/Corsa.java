package model;

import java.sql.Time;
import java.util.Date;

/**
 * The type Corsa.
 */
public class Corsa {

    private int id_corsa;
    private Date data;
    private Time orario_P;
    private Time orario_A;
    private float prezzo_I;
    private float prezzo_R;
    private boolean cancellazione=false;
    private int ritardo=0;
    private String porto_P;
    private String porto_A;
    private int postirimasti_P;
    private int postirimasti_A;
    private Natante natante;
    private Cadenza cadenza;

    /**
     * Instantiates a new Corsa.
     *
     * @param id_corsa the id corsa
     * @param data     the data
     * @param orario_P the orario p
     * @param orario_A the orario a
     * @param prezzo_I the prezzo i
     * @param prezzo_R the prezzo r
     * @param porto_P  the porto p
     * @param porto_A  the porto a
     * @param natante  the natante
     * @param cadenza  the cadenza
     */
//inserimento nuova corsa
    public Corsa(int id_corsa, Date data, Time orario_P, Time orario_A, float prezzo_I, float prezzo_R,
                 String porto_P, String porto_A, Natante natante, Cadenza cadenza) {

        if(natante.getTipo().equals("Traghetto")){
            this.postirimasti_A=natante.getCapienzaA();
        }else {
           this.postirimasti_A=0;
        }
        this.id_corsa=id_corsa;
        this.cadenza=cadenza;
        this.data = data;
        this.orario_P = orario_P;
        this.orario_A = orario_A;
        this.prezzo_I = prezzo_I;
        this.prezzo_R = prezzo_R;
        this.porto_P = porto_P;
        this.porto_A = porto_A;
        this.postirimasti_P = natante.getCapienzaP();
        this.natante = natante;
    }

    /**
     * Instantiates a new Corsa.
     *
     * @param id_corsa  the id corsa
     * @param data      the data
     * @param orario_P  the orario p
     * @param orario_A  the orario a
     * @param prezzo_I  the prezzo i
     * @param prezzo_R  the prezzo r
     * @param porto_P   the porto p
     * @param porto_A   the porto a
     * @param natante   the natante
     * @param cadenza   the cadenza
     * @param capienzaP the capienza p
     * @param capienzaA the capienza a
     * @param ritardo   the ritardo
     */
//corsa selezionata in pre prenotazione biglietto
    public Corsa(int id_corsa, Date data, Time orario_P, Time orario_A, float prezzo_I, float prezzo_R,
                 String porto_P, String porto_A, Natante natante, Cadenza cadenza,int capienzaP,int  capienzaA,int ritardo) {

        if(natante.getTipo().equals("Traghetto")){
            this.postirimasti_A=capienzaA;
        }else {
            this.postirimasti_A=0;
        }
        this.id_corsa=id_corsa;
        this.cadenza=cadenza;
        this.data = data;
        this.orario_P = orario_P;
        this.orario_A = orario_A;
        this.prezzo_I = prezzo_I;
        this.prezzo_R = prezzo_R;
        this.porto_P = porto_P;
        this.porto_A = porto_A;
        this.postirimasti_P = capienzaP;
        this.natante = natante;
        this.ritardo=ritardo;
    }

    /**
     * Instantiates a new Corsa.
     *
     * @param id_corsa the id corsa
     * @param data     the data
     * @param orario_P the orario p
     * @param orario_A the orario a
     * @param prezzo_I the prezzo i
     * @param prezzo_R the prezzo r
     * @param porto_P  the porto p
     * @param porto_A  the porto a
     * @param natante  the natante
     */
//visualizzazione Biglietti
    public Corsa(int id_corsa, Date data, Time orario_P, Time orario_A, float prezzo_I, float prezzo_R,
                 String porto_P, String porto_A, Natante natante) {
        this.id_corsa=id_corsa;
        this.data = data;
        this.orario_P = orario_P;
        this.orario_A = orario_A;
        this.prezzo_I = prezzo_I;
        this.prezzo_R = prezzo_R;
        this.porto_P = porto_P;
        this.porto_A = porto_A;
        this.natante = natante;
    }


    /**
     * Instantiates a new Corsa.
     *
     * @param orario_P the orario p
     * @param orario_A the orario a
     * @param prezzo_I the prezzo i
     * @param prezzo_R the prezzo r
     * @param porto_P  the porto p
     * @param porto_A  the porto a
     * @param natante  the natante
     */
    public Corsa(Time orario_P, Time orario_A, float prezzo_I,float prezzo_R,
                  String porto_P, String porto_A, Natante natante) {
        this.orario_P = orario_P;
        this.orario_A = orario_A;
        this.prezzo_I = prezzo_I;
        this.prezzo_R = prezzo_R;
        this.porto_P = porto_P;
        this.porto_A = porto_A;
        this.postirimasti_P = natante.getCapienzaP();
        this.natante = natante;
    }

    /**
     * Gets data.
     *
     * @return the data
     */
    public Date getData() {
        return data;
    }

    /**
     * Sets data.
     *
     * @param data the data
     */
    public void setData(Date data) {
        this.data = data;
    }

    /**
     * Gets orario p.
     *
     * @return the orario p
     */
    public Time getOrario_P() {
        return orario_P;
    }

    /**
     * Sets orario p.
     *
     * @param orario_P the orario p
     */
    public void setOrario_P(Time orario_P) {
        this.orario_P = orario_P;
    }

    /**
     * Gets orario a.
     *
     * @return the orario a
     */
    public Time getOrario_A() {
        return orario_A;
    }

    /**
     * Sets orario a.
     *
     * @param orario_A the orario a
     */
    public void setOrario_A(Time orario_A) {
        this.orario_A = orario_A;
    }

    /**
     * Gets prezzo i.
     *
     * @return the prezzo i
     */
    public float getPrezzo_I() {
        return prezzo_I;
    }

    /**
     * Sets prezzo i.
     *
     * @param prezzo_I the prezzo i
     */
    public void setPrezzo_I(float prezzo_I) {
        this.prezzo_I = prezzo_I;
    }

    /**
     * Gets prezzo r.
     *
     * @return the prezzo r
     */
    public float getPrezzo_R() {
        return prezzo_R;
    }

    /**
     * Sets prezzo r.
     *
     * @param prezzo_R the prezzo r
     */
    public void setPrezzo_R(float prezzo_R) {
        this.prezzo_R = prezzo_R;
    }

    /**
     * Is cancellazione boolean.
     *
     * @return the boolean
     */
    public boolean isCancellazione() {
        return cancellazione;
    }

    /**
     * Sets cancellazione.
     *
     * @param cancellazione the cancellazione
     */
    public void setCancellazione(boolean cancellazione) {
        this.cancellazione = cancellazione;
    }

    /**
     * Gets ritardo.
     *
     * @return the ritardo
     */
    public int getRitardo() {
        return ritardo;
    }

    /**
     * Sets ritardo.
     *
     * @param ritardo the ritardo
     */
    public void setRitardo(int ritardo) {
        this.ritardo = ritardo;
    }

    /**
     * Gets postirimasti p.
     *
     * @return the postirimasti p
     */
    public int getPostirimasti_P() {
        return postirimasti_P;
    }

    /**
     * Sets postirimasti p.
     *
     * @param postirimasti_P the postirimasti p
     */
    public void setPostirimasti_P(int postirimasti_P) {
        this.postirimasti_P = postirimasti_P;
    }

    /**
     * Gets postirimasti a.
     *
     * @return the postirimasti a
     */
    public int getPostirimasti_A() {
        return postirimasti_A;
    }

    /**
     * Sets postirimasti a.
     *
     * @param postirimasti_A the postirimasti a
     */
    public void setPostirimasti_A(int postirimasti_A) {
        this.postirimasti_A = postirimasti_A;
    }

    /**
     * Gets natante.
     *
     * @return the natante
     */
    public Natante getNatante() {
        return natante;
    }

    /**
     * Gets cadenza.
     *
     * @return the cadenza
     */
    public Cadenza getCadenza() {
        return cadenza;
    }

    /**
     * Sets cadenza.
     *
     * @param cadenza the cadenza
     */
    public void setCadenza(Cadenza cadenza) {
        this.cadenza = cadenza;
    }

    /**
     * Gets id corsa.
     *
     * @return the id corsa
     */
    public int getId_corsa() {
        return id_corsa;
    }

    /**
     * Sets id corsa.
     *
     * @param id_corsa the id corsa
     */
    public void setId_corsa(int id_corsa) {
        id_corsa = id_corsa;
    }

    /**
     * Sets natante.
     *
     * @param natante the natante
     */
    public void setNatante(Natante natante) {
        this.natante = natante;
    }

    /**
     * Gets porto p.
     *
     * @return the porto p
     */
    public String getPorto_P() {
        return porto_P;
    }

    /**
     * Sets porto p.
     *
     * @param porto_P the porto p
     */
    public void setPorto_P(String porto_P) {
        this.porto_P = porto_P;
    }

    /**
     * Gets porto a.
     *
     * @return the porto a
     */
    public String getPorto_A() {
        return porto_A;
    }

    /**
     * Sets porto a.
     *
     * @param porto_A the porto a
     */
    public void setPorto_A(String porto_A) {
        this.porto_A = porto_A;
    }
}
