package GUI;

import Controller.Controller;
import model.Compagnia;
import model.Corsa;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

/**
 * The type Lista corse comp.
 */
public class ListaCorseComp {

    /**
     * The Frame.
     */
    public  JFrame frame;
    private JButton backButton;
    private JTable tableCorse;
    private JScrollPane scrollPane;
    private JComboBox comboBoxCorseId;
    private JButton eliminaButton;
    private JButton segnalaRitardoButton;
    private JPanel panelCorse;
    private JButton modificaPrezzoButton;

    /**
     * Instantiates a new Lista corse comp.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public ListaCorseComp(JFrame frameChiamante , Controller controller) {

        frame = new JFrame("ListaNatanti");
        frame.setContentPane(panelCorse);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1400, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        controller.cercaCorseComp();
        tableCorse.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        DefaultTableModel tabelModel = new DefaultTableModel(new Object[][]{}, new String[]{"ID", "Porto Partenza", "Porto Arrivo", "Data", "Orario Partenza", "Orario Arrivo ", "Natante", "Prezzo Intero", "Prezzo ridotto", "Posti rimasti", "Posti auto rimasti"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableCorse.setEnabled(true);
        tableCorse.setModel(tabelModel);
        tableCorse.getTableHeader().setReorderingAllowed(false);

        /** riempiamo la tabella con tutte le corse della compagnia */

        for (int i = tabelModel.getRowCount(); i <controller.GrandeZZAArreyCors(); i++) {
            if(controller.getRitardo(i)!=0){

                tabelModel.addRow(new Object[]{controller.getId_corsa(i), controller.getPorto_P(i), controller.getPorto_A(i), controller.getData(i),
                        controller.getOrario_P(i)+ " Ritardo Segnalato : "+controller.getRitardo(i), controller.getOrario_A(i), controller.getTipoNatCorsa(i)+" ID :"+controller.getId_NatanteCorsa(i), controller.getPrezzo_I(i),controller.getPrezzo_R(i),
                        controller.getPostirimasti_P(i),controller.getPostirimasti_A(i)});

            }else {
                tabelModel.addRow(new Object[]{controller.getId_corsa(i), controller.getPorto_P(i), controller.getPorto_A(i), controller.getData(i),
                        controller.getOrario_P(i), controller.getOrario_A(i), controller.getTipoNatCorsa(i)+" ID :"+controller.getId_NatanteCorsa(i), controller.getPrezzo_I(i),controller.getPrezzo_R(i),
                        controller.getPostirimasti_P(i),controller.getPostirimasti_A(i)});
            }
            comboBoxCorseId.addItem(controller.getId_corsa(i));
        }

        modificaPrezzoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String prezzoI = JOptionPane.showInputDialog("Inserire Prezzo Intero corsa  : ");
                String prezzoR = JOptionPane.showInputDialog("Inserire Prezzo Ridotto corsa : ");

                Float prezzoRidotto;
                Float prezzoIntero;
                try {
                    prezzoRidotto = Float.valueOf(prezzoI);
                    prezzoIntero = prezzoRidotto;
                    if (prezzoIntero <=0) throw new Exception();
                    prezzoRidotto = Float.valueOf(prezzoR);
                    if (prezzoRidotto <= 0) throw new Exception();
                } catch (Exception exception) {
                    prezzoRidotto = null;
                    prezzoIntero = null;
                    JOptionPane.showMessageDialog(null, "Prezzo non valido");
                }
                if (prezzoI != null && prezzoR != null) {

                    /** il metodo modificaPrezzi aggiorna sulla base dati il
                     *  prezzo intero e ridotto della corsa selezionata */

                    String messaggio = controller.modificaPrezzi(Integer.valueOf(comboBoxCorseId.getSelectedItem().toString()),prezzoIntero ,prezzoRidotto );
                    if (messaggio.equals("")) {
                        JOptionPane.showMessageDialog(null, "Prezzi modificati");
                        controller.SvuotaArreyCor();
                        frameChiamante.setVisible(true);
                        frame.dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, messaggio);
                    }
                }


            }
        });

        segnalaRitardoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                SpinnerNumberModel sModel = new SpinnerNumberModel(0, 0, 60, 15);
                JSpinner spinnerRitardo = new JSpinner(sModel);

                spinnerRitardo.addKeyListener(new KeyListener() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyPressed(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyReleased(KeyEvent e) {
                        e.consume();
                    }
                });

                int option = JOptionPane.showOptionDialog(null, spinnerRitardo, "Enter valid number", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
                if (option == JOptionPane.CANCEL_OPTION) {


                } else if (option == JOptionPane.OK_OPTION) {

                    /** il metodo RitardoCorsa aggiorna sul database la corsa
                     *  selezionata aggiungendole i minuti di ritardo scelti dalla compagnia */

                    String messaggio = controller.RitardoCorsa(Integer.valueOf(comboBoxCorseId.getSelectedItem().toString()),Integer.valueOf(spinnerRitardo.getValue().toString()));
                    if (messaggio.equals("")) {
                        JOptionPane.showMessageDialog(null,"Modifica Effetutata");
                        controller.SvuotaArreyCor();
                        frameChiamante.setVisible(true);
                        frame.dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, messaggio);
                    }
                }
            }
        });

        eliminaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] opzioni = {"Si", "No"};
                int option = JOptionPane.showOptionDialog(null, "Sei sicuro di voler eliminare questa Corsa?", "Warning", 0, 2, UIManager.getIcon("OptionPane.warningIcon"), opzioni, opzioni[0]);
                if (option == 0) {

                    /** il metodo CancellaCoresa imposta sul databse il campo
                     *  cancellazione della corsa a true e ne impedisce la
                     *   visione ai clienti */

                    String erorr=controller.CancellaCorsa(Integer.valueOf(comboBoxCorseId.getSelectedItem().toString()));
                    if(!erorr.equals("")){
                        JOptionPane.showMessageDialog(null,erorr,"Erorr",JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                    }else {
                        JOptionPane.showMessageDialog(null,"Corsa :"+comboBoxCorseId.getSelectedItem()+" cancellata");
                        controller.SvuotaArreyCor();
                        frameChiamante.setVisible(true);
                        frame.dispose();
                    }
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.SvuotaArreyCor();
                frameChiamante.setVisible(true);
                frame.dispose();
            }
        });
    }
}

