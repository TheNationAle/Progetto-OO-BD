package model;

/**
 * The type Autoveicolo.
 */
public class Autoveicolo {
    private String tipo;
    private float sovraprezzo_A;
    private int dimensione;
    private Compagnia compagnia;

    /**
     * Instantiates a new Autoveicolo.
     *
     * @param tipo          the tipo
     * @param sovraprezzo_A the sovraprezzo a
     * @param dimensione    the dimensione
     * @param compagnia     the compagnia
     */
    public Autoveicolo(String tipo, float sovraprezzo_A, int dimensione, Compagnia compagnia) {
        this.tipo = tipo;
        this.sovraprezzo_A = sovraprezzo_A;
        this.dimensione = dimensione;
        this.compagnia = compagnia;
    }

    /**
     * Gets sovraprezzo a.
     *
     * @return the sovraprezzo a
     */
    public float getSovraprezzo_A() {
        return sovraprezzo_A;
    }

    /**
     * Sets sovraprezzo a.
     *
     * @param sovraprezzo_A the sovraprezzo a
     */
    public void setSovraprezzo_A(float sovraprezzo_A) {
        this.sovraprezzo_A = sovraprezzo_A;
    }

    /**
     * Gets dimensione.
     *
     * @return the dimensione
     */
    public int getDimensione() {
        return dimensione;
    }

    /**
     * Sets dimenzione.
     *
     * @param dimenzione the dimenzione
     */
    public void setDimenzione(int dimenzione) {
        this.dimensione = dimenzione;
    }

    /**
     * Sets compagnia.
     *
     * @param compagnia the compagnia
     */
    public void setCompagnia(Compagnia compagnia) {
        this.compagnia = compagnia;
    }

    /**
     * Gets tipo.
     *
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Sets tipo.
     *
     * @param tipo the tipo
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * Gets compagnia.
     *
     * @return the compagnia
     */
    public Compagnia getCompagnia() {
        return compagnia;
    }
}
