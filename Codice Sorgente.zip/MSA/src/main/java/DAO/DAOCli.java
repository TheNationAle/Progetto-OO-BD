package DAO;

import model.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 * The interface Dao cli.
 */
public interface DAOCli {
    /**
     * Controllo credenziali cli cliente.
     *
     * @param Cli the cli
     * @return the cliente
     */
    Cliente ControlloCredenzialiCli(Cliente Cli);

    /**
     * Registra cli db string.
     *
     * @param cli the cli
     * @return the string
     */
    String RegistraCliDb(Cliente cli);

    /**
     * Cerca portidb.
     *
     * @param porti the porti
     */
    void CercaPortidb(ArrayList<Porto> porti);

    /**
     * Cerca corse string.
     *
     * @param corsa  the corsa
     * @param portoP the porto p
     * @param portoA the porto a
     * @param d      the d
     * @param t      the t
     * @param prezzo the prezzo
     * @return the string
     */
    String cercaCorse(ArrayList<Corsa> corsa, String portoP, String portoA, LocalDate d, LocalTime t,int prezzo);

    /**
     * Cerca corse s string.
     *
     * @param corsa  the corsa
     * @param portoP the porto p
     * @param portoA the porto a
     * @param d      the d
     * @param t      the t
     * @return the string
     */
    String cercaCorseS(ArrayList<Corsa> corsa, String portoP, String portoA, LocalDate d, LocalTime t);

    /**
     * Auto veicoli compin corsa.
     *
     * @param comp the comp
     */
    void autoVeicoliCompinCorsa(Compagnia comp);

    /**
     * Aggiungi biglietto string.
     *
     * @param cli         the cli
     * @param cor         the cor
     * @param bag         the bag
     * @param autoveicolo the autoveicolo
     * @param disa        the disa
     * @param preno       the preno
     * @return the string
     */
    String aggiungiBiglietto(Cliente cli,Corsa cor,int bag,String autoveicolo,boolean disa,boolean preno);

    /**
     * Gets biglietti prenotati.
     *
     * @param cli the cli
     */
    void getBigliettiPrenotati(Cliente cli);

    /**
     * Elimina biglietti.
     *
     * @param bigli the bigli
     */
    void eliminaBiglietti(Biglietto bigli);

    /**
     * Update cli string.
     *
     * @param nome      the nome
     * @param cognome   the cognome
     * @param localDate the local date
     * @param sex       the sex
     * @param pass      the pass
     * @param email     the email
     * @return the string
     */
    String updateCli(String nome, String cognome, LocalDate localDate, String sex, String pass, String email);

}
