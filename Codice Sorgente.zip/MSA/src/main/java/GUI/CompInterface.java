package GUI;

import Controller.Controller;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The type Comp interface.
 */
public class CompInterface {

    /**
     * The Frame.
     */
    public  JFrame frame;
    private JButton visualizzaCorseButton;
    private JButton creaCorseButton;
    private JPanel panelCinterface;
    private JButton visualizzaNatantiButton;
    private JButton logOutButton;
    private JButton aggiungiNatanteButton;
    private JButton visualizzaAutoveicoliButton;
    private JButton modificaCadenzaButton;
    private JButton modificaDatiCompagniaButton;

    /**
     * Instantiates a new Comp interface.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public CompInterface(JFrame frameChiamante , Controller controller){
        frame = new JFrame("CompInterface");
        frame.setContentPane(panelCinterface);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        creaCorseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                /** il metodo ListaNat prende tutti i natanti della compagnia che ha fatto l'accesso*/

                controller.ListaNat();
                CreazioneCorse creazioneCorse = new CreazioneCorse(frame, controller);
                creazioneCorse.frame.setVisible(true);
                frame.setVisible(false);

            }
        });

        aggiungiNatanteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CreazioneNatante creaN = new CreazioneNatante(frame,controller);
                creaN.frame.setVisible(true);
                frame.setVisible(false);
            }
        });

        visualizzaNatantiButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {

               controller.ListaNat();
               ListaNatanti listaNat=new ListaNatanti(frame,controller);
               listaNat.frame.setVisible(true);
               frame.setVisible(false);
           }
        });

        visualizzaCorseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                ListaCorseComp listaCorseComp = new ListaCorseComp(frame, controller);
                listaCorseComp.frame.setVisible(true);
                frame.setVisible(false);

            }
        });

        modificaDatiCompagniaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ModificaDatiComp modComp= new ModificaDatiComp(frame,controller);
                modComp.frame.setVisible(true);
                frame.setVisible(false);

            }
        });

        visualizzaAutoveicoliButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ListaAutoveicoli listaAuto = new ListaAutoveicoli(frame,controller);
                listaAuto.frame.setVisible(true);
                frame.setVisible(false);

            }
        });

        modificaCadenzaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modificaCadenzaCorse modCC= new modificaCadenzaCorse(frame,controller);
                modCC.frame.setVisible(true);
                frame.setVisible(false);

            }
        });

        logOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameChiamante.setVisible(true);
                frame.setVisible(false);
            }
        });

    }


}
