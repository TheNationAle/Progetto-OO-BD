package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * The type Modifica cadenza.
 */
public class ModificaCadenza {

    /**
     * The Frame.
     */
    public JFrame frame;
    private JTextField textFieldPeriodoF;
    private JTextField textFieldPriodoI;
    private JCheckBox lunediCheckBox;
    private JCheckBox giovediCheckBox;
    private JCheckBox martediCheckBox;
    private JCheckBox mercolediCheckBox;
    private JCheckBox venerdiCheckBox;
    private JCheckBox sabatoCheckBox;
    private JCheckBox domenicaCheckBox;
    private JButton backButton;
    private JButton confermaModificaButton;
    private JPanel panelModificaCad;
    private JSpinner spinnerEuroPrezzoI;
    private JSpinner spinnerCentesimiPrezzoI;
    private JSpinner spinnerEuroPrezzoR;
    private JSpinner spinnerCentesimiPrezzoR;

    /**
     * Instantiates a new Modifica cadenza.
     *
     * @param originalChiamante the original chiamante
     * @param frameChiamante    the frame chiamante
     * @param controller        the controller
     * @param idCadenza         the id cadenza
     */
    public ModificaCadenza(JFrame originalChiamante ,JFrame frameChiamante, Controller controller,int idCadenza){

        frame = new JFrame("CompInterface");
        frame.setContentPane(panelModificaCad);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        /** selezioniamo la cadenza selezionata dalla compagnia */

        for (int i=0;i<controller.GrandeZZAArreyCors();i++){
            if(controller.getId_cad(i)==idCadenza){

                textFieldPriodoI.setText(controller.getPeriodo_I(i).toString());
                textFieldPeriodoF.setText(controller.getPeriodo_F(i).toString());

                /** limitiamo gli spinner */

                SpinnerNumberModel numberEuroP = new SpinnerNumberModel();
                numberEuroP.setMaximum(999);
                numberEuroP.setMinimum(0);

                SpinnerNumberModel numberCentP= new SpinnerNumberModel();
                numberCentP.setMaximum(99);
                numberCentP.setMinimum(0);

                SpinnerNumberModel numberEuroB = new SpinnerNumberModel();
                numberEuroB.setMaximum(999);
                numberEuroB.setMinimum(0);

                SpinnerNumberModel numberCentB= new SpinnerNumberModel();
                numberCentB.setMaximum(99);
                numberCentB.setMinimum(0);

                spinnerEuroPrezzoI.setModel(numberEuroP);
                spinnerEuroPrezzoI.addKeyListener(new KeyListener() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyPressed(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyReleased(KeyEvent e) {
                        e.consume();
                    }
                });

                spinnerCentesimiPrezzoR.setModel(numberCentP);
                spinnerCentesimiPrezzoR.addKeyListener(new KeyListener() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyPressed(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyReleased(KeyEvent e) {
                        e.consume();
                    }
                });

                spinnerEuroPrezzoR.setModel(numberEuroB);
                spinnerEuroPrezzoR.addKeyListener(new KeyListener() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyPressed(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyReleased(KeyEvent e) {
                        e.consume();
                    }
                });

                spinnerCentesimiPrezzoR.setModel(numberCentB);
                spinnerCentesimiPrezzoR.addKeyListener(new KeyListener() {
                    @Override
                    public void keyTyped(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyPressed(KeyEvent e) {
                        e.consume();
                    }

                    @Override
                    public void keyReleased(KeyEvent e) {
                        e.consume();
                    }
                });

                spinnerEuroPrezzoI.setValue((int)controller.getPrezzo_I(i));
                spinnerCentesimiPrezzoR.setValue((int) ((controller.getPrezzo_R(i) % 1) * 100));

                spinnerEuroPrezzoR.setValue((int)controller.getPrezzo_R(i));
                spinnerCentesimiPrezzoR.setValue((int) ((controller.getPrezzo_R(i) % 1) * 100));

                /** inizializziamo le checkbox con i precedenti giorni
                 * della settimana selezionati per questa cadenza */

                if(controller.getGiorni(i).contains("Monday")){
                    lunediCheckBox.setSelected(true);
                }
                if(controller.getGiorni(i).contains("Tuesday")){
                    martediCheckBox.setSelected(true);
                }
                if(controller.getGiorni(i).contains("Wednesday")){
                    mercolediCheckBox.setSelected(true);
                }
                if(controller.getGiorni(i).contains("Thursday")){
                    giovediCheckBox.setSelected(true);
                }
                if(controller.getGiorni(i).contains("Friday")){
                    venerdiCheckBox.setSelected(true);
                }
                if(controller.getGiorni(i).contains("Saturday")){
                    sabatoCheckBox.setSelected(true);
                }
                if(controller.getGiorni(i).contains("Sunday")){
                    domenicaCheckBox.setSelected(true);
                }
            }
        }

        confermaModificaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    LocalDate dataI = null;
                    LocalDate dataR = null;
                    String giorni = "";

                    /** prepariamo i dati per la modifica */

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ITALIAN);
                    dataI = LocalDate.parse(textFieldPriodoI.getText(), formatter);
                    dataR = LocalDate.parse(textFieldPeriodoF.getText(), formatter);

                    if (lunediCheckBox.isSelected()) giorni = giorni + "Monday, ";
                    if (martediCheckBox.isSelected()) giorni = giorni + "Tuesday, ";
                    if (mercolediCheckBox.isSelected()) giorni = giorni + "Wednesday, ";
                    if (giovediCheckBox.isSelected()) giorni = giorni + "Thursday, ";
                    if (venerdiCheckBox.isSelected()) giorni = giorni + "Friday, ";
                    if (sabatoCheckBox.isSelected()) giorni = giorni + "Saturday, ";
                    if (domenicaCheckBox.isSelected()) giorni = giorni + "Sunday, ";

                    giorni = giorni.substring(0, giorni.length() - 2);

                    /** il metodo modificaCadenza modificaCadenza modifica
                     *  sul database i dati della cadenza selezionata */

                    String erorr=controller.modificaCadenza(idCadenza,giorni,dataI,dataR,
                            Float.valueOf(spinnerEuroPrezzoI.getValue().toString()+"."+spinnerCentesimiPrezzoI.getValue().toString()),
                            Float.valueOf(spinnerEuroPrezzoR.getValue().toString()+"."+spinnerCentesimiPrezzoR.getValue().toString()));
                    if(!erorr.equals("")){
                        JOptionPane.showMessageDialog(null,erorr,"Erorr",JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                    }else {
                        JOptionPane.showMessageDialog(null,"Modifiche Efettuate");
                        controller.SvuotaArreyCor();
                        originalChiamante.setVisible(true);
                        frame.dispose();
                    }

                } catch (DateTimeException dateTimeException) {
                    JOptionPane.showMessageDialog(null, "Inserire un periodo valido (YYYY-MM-dd)");
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameChiamante.setVisible(true);
                frame.dispose();
            }
        });
    }
}
