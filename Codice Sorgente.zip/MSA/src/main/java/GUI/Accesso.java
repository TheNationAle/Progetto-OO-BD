package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The type Accesso.
 */
public class Accesso {

    /**
     * The Frame.
     */
    public JFrame frame;
    private JPanel panel;
    private JLabel titolo;
    private JTextField emailField1;
    private JLabel email;
    private JButton accediButton;
    private JLabel password;
    private JPasswordField passwordField1;
    private JButton homePageButton;
    private JButton registrazioneButton;


    /**
     * Instantiates a new Acesso.
     *
     * @param frameChiamante the frame chiamante
     * @param nome           the nome
     * @param controller     the controller
     */
    public Accesso(JFrame frameChiamante , String nome, Controller controller)
    {
        frame=new JFrame("Accesso");
        frame.setContentPane(panel);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        SwingUtilities.invokeLater(()-> titolo.setText(titolo.getText()+" "+nome));

        //Rendiamo visibile il bottone registrazione solo durante l'accesso di un utente.

        if("Clienti" != nome){
            registrazioneButton.setVisible(false);
        }


        accediButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if("Clienti" == nome){

                    //la funzione ControllaCredenzialiCli controlla se l'email e password inserite esistono sul database
                    //e nel caso permettono al Cliente il login sul suo accout.

                  if(controller.ControllaCredenzialiCli(emailField1.getText(), passwordField1.getText())){
                      JOptionPane.showMessageDialog(null,"Sei pronto a Salpare",null,JOptionPane.OK_OPTION , UIManager.getIcon("OptionPane.questionIcon"));

                      //resettiamo i campi email e password così nel caso l'utente tornasse indietro
                      //non verranno visualizzati a schermo l'email e la password inseriti in precedenza.

                      emailField1.setText("");
                      passwordField1.setText("");
                      CliInterface cliInterface=new CliInterface(frame,controller);
                      cliInterface.frame.setVisible(true);
                      frame.setVisible(false);
                      emailField1.setText("");
                      passwordField1.setText("");

                  }else{
                      JOptionPane.showMessageDialog(null,"Email o Password errata");

                  }
                }else if ("Compagnia" == nome){

                    /**la funzione ControllaCredenzialiComp controlla se l'email e password inserite esistono sul database
                    e nel caso permettono alla compagnia il login sul suo accout.*/

                    if(controller.ControllaCredenzialiComp(emailField1.getText(), passwordField1.getText())){
                        JOptionPane.showMessageDialog(null,"Sei pronto a far Salpare",null,JOptionPane.OK_OPTION , UIManager.getIcon("OptionPane.questionIcon"));
                        CompInterface interFace=new CompInterface(frame,controller);
                        interFace.frame.setVisible(true);
                        frame.setVisible(false);
                        emailField1.setText("");
                        passwordField1.setText("");

                    }else {
                        JOptionPane.showMessageDialog(null,"Email o Password errata");
                    }

                }

            }
        });


        registrazioneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RegistrazioneCli regg=new RegistrazioneCli(frame,controller);
                regg.frame.setVisible(true);
                frame.setVisible(false);

            }
        });


        homePageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameChiamante.setVisible(true);
                frame.dispose();
            }
        });
    }


}