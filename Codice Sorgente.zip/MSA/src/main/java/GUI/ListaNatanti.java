package GUI;

import Controller.Controller;
import model.Compagnia;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The type Lista natanti.
 */
public class ListaNatanti {
    /**
     * The Frame.
     */
    public  JFrame frame;
    private JPanel panelListaNatanti;
    private JTable natanti;
    private JButton modificaButton;
    private JButton eliminaButton;
    private JButton backButton;
    private JComboBox comboBoxNat;
    private JScrollPane scrollPane;

    /**
     * Instantiates a new Lista natanti.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public ListaNatanti(JFrame frameChiamante , Controller controller) {

        JFrame framechiamate = frameChiamante;
        frame = new JFrame("ListaNatanti");
        frame.setContentPane(panelListaNatanti);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1400,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        natanti.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        DefaultTableModel tabelModel = new DefaultTableModel(new Object[][]{}, new String[]{"ID", "NOME", "Compagnia","Tipo", "Capienza Persone", "Capienza Autoveicoli", "In Utilizzo"});

        natanti.setModel(tabelModel);
        natanti.setEnabled(false);
        natanti.getTableHeader().setReorderingAllowed(false);

        /** riempiamo la tabella con le specifiche di tutti i natanti della compagnia */

        for (int i = tabelModel.getRowCount(); i < controller.GrandeZZAArreyNat(); i++) {
            tabelModel.addRow(new Object[]{controller.getId_NatanteComp(i), controller.getNomeNatComp(i),
                    controller.getNomeCompagniaComp(i), controller.getTipoNatComp(i),controller.getCapienzaPComp(i),
                    controller.getCapienzaAComp(i), Boolean.toString(controller.InUtilizzoNat(i)).toUpperCase()});

            comboBoxNat.addItem(controller.getId_NatanteComp(i));

        }

        eliminaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] opzioni = {"Si", "No"};
                int option = JOptionPane.showOptionDialog(null, "Sei sicuro di voler eliminare questo natante?", "Warning", 0, 2, UIManager.getIcon("OptionPane.warningIcon"), opzioni, opzioni[0]);
                if(option == 0) {

                    /** il metodo eliminaNatante elimina dalla base dati il natante selezionato */

                    controller.eliminaNatante(Integer.valueOf(comboBoxNat.getSelectedItem().toString()));
                   controller.SvuotaArreyNatCompag();
                    framechiamate.setVisible(true);
                    frame.dispose();
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.SvuotaArreyNatCompag();
                framechiamate.setVisible(true);
                frame.dispose();

            }
        });

        modificaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String nome = JOptionPane.showInputDialog("Inserire il nuovo nome del natante selezionato");
                if (nome != null){

                    /** il metodo modificaNome modifica nella base dati il nome del natante selezionato  */

                    String messaggio = controller.modificaNome(Integer.valueOf(comboBoxNat.getSelectedItem().toString()), nome);
                    JOptionPane.showMessageDialog(null, messaggio);
                    if (messaggio.equals("Nome del natante modificato")){
                        controller.SvuotaArreyNatCompag();
                        framechiamate.setVisible(true);
                        frame.dispose();
                    }
                }

            }
        });

    }
}

