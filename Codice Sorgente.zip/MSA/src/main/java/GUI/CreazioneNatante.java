package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The type Creazione natante.
 */
public class CreazioneNatante {

    /**
     * The Frame.
     */
    public JFrame frame;
    private JButton insersciNatanteButton;
    private JButton backButton;
    private JComboBox comboBoxTipoNat;
    private JTextField textFieldNomeNat;
    private JTextField textFieldCP;
    private JTextField textFieldCA;
    private JPanel panelCreaNat;

    /**
     * Instantiates a new Creazione natante.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public CreazioneNatante(JFrame frameChiamante , Controller controller){
        frame = new JFrame("CreazioneNatante");
        frame.setContentPane(panelCreaNat);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        comboBoxTipoNat.addItem("Traghetto");
        comboBoxTipoNat.addItem("Motonave");
        comboBoxTipoNat.addItem("Aliscafo");

        insersciNatanteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                /** controlliamo che sia stata inserita la capienza del natante */

                if(!textFieldCP.getText().equals("")) {
                    if (Integer.valueOf(textFieldCP.getText().toString()) <= 0) {
                        JOptionPane.showMessageDialog(null, "Numero Passeggeri non Valido");
                    } else {
                        String erorr = null;
                        if (comboBoxTipoNat.getSelectedItem().equals("Traghetto") && (!(Integer.valueOf(textFieldCA.getText()) <= 0))) {
                           if(!textFieldCA.getText().equals("")) {

                               /** il metodo inserisciNat inserisce all'interno del database un natante
                                *  con i dati inseriti in input dalla compagnia */

                               erorr = controller.inserisciNat(textFieldNomeNat.getText(), comboBoxTipoNat.getSelectedItem().toString(), Integer.valueOf(textFieldCP.getText()), Integer.valueOf(textFieldCA.getText()));
                               if (erorr.equals("")) {
                                   JOptionPane.showMessageDialog(null, "Natante Inserito");
                               } else {
                                   JOptionPane.showMessageDialog(null, erorr);
                               }
                           }

                        } else if (!comboBoxTipoNat.getSelectedItem().equals("Traghetto")) {
                            textFieldCA.setText("0");
                            erorr = controller.inserisciNat(textFieldNomeNat.getText(), comboBoxTipoNat.getSelectedItem().toString(), Integer.valueOf(textFieldCP.getText()), Integer.valueOf(textFieldCA.getText()));
                            if (erorr.equals("")) {
                                JOptionPane.showMessageDialog(null, "Natante Inserito");
                            } else {
                                JOptionPane.showMessageDialog(null, erorr);
                            }

                        } else {
                            JOptionPane.showMessageDialog(null, "Numero Autoveicoli non Valido");
                        }

                    }
                }
            }
        });


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameChiamante.setVisible(true);
                frame.dispose();
            }
        });
    }

}
