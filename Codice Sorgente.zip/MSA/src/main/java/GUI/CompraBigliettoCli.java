package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;

/**
 * The type Compra biglietto cli.
 */
public class CompraBigliettoCli {

    /**
     * The Frame.
     */
    public JFrame frame;
    private JButton confermaAquistoButton;
    private JButton tornaASelezioneButton;
    private JComboBox comboBoxB;
    private JComboBox comboBoxAutoveiclo;
    private JList listaPrezzi;
    private JCheckBox passegieroAffettoDaDisabilitaCheckBox;
    private JPanel pannelBiglietti;
    private JButton calcolaPrezzoFinaleButton;

    /**
     * Instantiates a new Compra biglietto cli.
     *
     * @param frameChiamante the frame chiamante
     * @param original       the original
     * @param controller     the controller
     * @param idCorsa        the id corsa
     * @param seScalo        the se scalo
     */
    public CompraBigliettoCli(JFrame frameChiamante, JFrame original , Controller controller, int idCorsa, boolean seScalo){

        frame=new JFrame("CompraBigliettoCli");
        frame.setContentPane(pannelBiglietti);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);


        comboBoxAutoveiclo.setEnabled(true);
        boolean prenotazion=false;
        int   id = 0;

        //numero massimo di bagagli
       for (int i=0;i<=5;i++){
           comboBoxB.addItem(String.valueOf(i));
       }

        DefaultListModel listModel = new DefaultListModel();
        listaPrezzi.setModel(listModel);


        float prezzoTot= 0.0F;
        //Se uno Scalo e' stato selezionato
        //Stampa delle specifiche dei biglietti
        if (seScalo==true){
            listModel.addElement("Prezzo Prima Corsa : "+controller.getPrezzo_I(idCorsa));
            prezzoTot=prezzoTot+controller.getPrezzo_I(idCorsa);
            listModel.addElement("Prezzo Seconda Corsa : "+controller.getPrezzo_I(idCorsa+1));
            prezzoTot=prezzoTot+controller.getPrezzo_I(idCorsa+1);


            if(controller.getTipoNatCorsa(idCorsa).equals("Traghetto") && controller.getTipoNatCorsa(idCorsa+1).equals("Traghetto")) {
                //se le eventuali compagnie offrono lo stesso tipo di AutoVeicolo

                controller.addAutoVeicoliCompinCorsa(idCorsa);
                controller.addAutoVeicoliCompinCorsa(idCorsa+1);

                comboBoxAutoveiclo.addItem("NULL");
                for (int i = 0; i<controller.GrandeZZAArreyAutoveicliCorsa(idCorsa); i++) {
                    for (int j = 0; j<controller.GrandeZZAArreyAutoveicliCorsa(idCorsa+1); j++) {
                        if (controller.getTipoAutoVCorsa(idCorsa,i).equals(controller.getTipoAutoVCorsa(idCorsa+1,j))){
                            comboBoxAutoveiclo.addItem(controller.getTipoAutoVCorsa(idCorsa,i));
                        }
                    }

                }
               if(comboBoxAutoveiclo.getItemCount()==1){
                   comboBoxAutoveiclo.removeAllItems();
                   comboBoxAutoveiclo.addItem("Nessun Autoveicolo disponibile");
               }
            }else{
                comboBoxAutoveiclo.addItem("Autoveicolo non trasportato da Natante");
                comboBoxAutoveiclo.setEnabled(false);
                }

            listModel.addElement("Prezzo Bagagli Prima Corsa : "+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(idCorsa)));
            prezzoTot=prezzoTot+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(idCorsa));
            listModel.addElement("Prezzo Bagagli Seconda Corsa : "+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(idCorsa+1)));
            prezzoTot=prezzoTot+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(idCorsa+1));

            if(controller.getData(idCorsa).compareTo(Date.from(Instant.now()))>0){
                listModel.addElement("Tassa Prenotazione Prima Corsa : "+controller.getSovraprezzo_PCorsa(idCorsa));
                prezzoTot=prezzoTot+controller.getSovraprezzo_PCorsa(idCorsa);
                listModel.addElement("Tassa Prenotazione Seconda Corsa : "+controller.getSovraprezzo_PCorsa(idCorsa+1));
                prezzoTot=prezzoTot+controller.getSovraprezzo_PCorsa(idCorsa+1);
                prenotazion=true;
            }
        }else {

            //Se la corsa selezionata e' Diretta
            //Stampa delle specifiche del biglietto
                    for (int i = 0; i<controller.GrandeZZAArreyCors(); i++) {
                        if(controller.getId_corsa(i)==idCorsa){
                            id=i;
                        }

                    }

                    controller.addAutoVeicoliCompinCorsa(id);

                    if(controller.getTipoNatCorsa(id).equals("Traghetto")){
                        comboBoxAutoveiclo.addItem("NULL");
                        for(int i = 0; i<controller.GrandeZZAArreyAutoveicliCorsa(id); i++){
                            comboBoxAutoveiclo.addItem(controller.getTipoAutoVCorsa(id,i));
                        }
                        if(comboBoxAutoveiclo.getItemCount()==1){
                            comboBoxAutoveiclo.removeAllItems();
                            comboBoxAutoveiclo.addItem("Nessun Autoveicolo disponibile");
                        }
                    }else {
                        comboBoxAutoveiclo.addItem("Autoveicolo non trasportato da Natante");
                        comboBoxAutoveiclo.setEnabled(false);
                    }
                    listModel.addElement("Prezzo corsa : "+controller.getPrezzo_I(id));
                    prezzoTot=prezzoTot+controller.getPrezzo_I(id);
                    listModel.addElement("Prezzo Bagagli : "+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(id)));
                    prezzoTot=prezzoTot+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(id));

                    if(controller.getData(id).compareTo(Date.from(Instant.now()))>0){
                        listModel.addElement("Tassa Prenotazione : "+controller.getSovraprezzo_PCorsa(id));
                        prezzoTot=prezzoTot+controller.getSovraprezzo_PCorsa(id);
                        prenotazion=true;
                    }
                }


        listModel.addElement("Tasse di commisione : " + String.format("%.2f", prezzoTot * 0.014));
        prezzoTot = (float) (prezzoTot + (prezzoTot * 0.014));
        listModel.addElement("------------------------------------------------------------------------");
        listModel.addElement("");
        listModel.addElement("Prezzo Totale : " + String.format("%.2f", prezzoTot));



        boolean finalPrenotazion = prenotazion;
        final int[] dimesione1 = new int[1];
        final int[] dimesione2 = new int[1];

        int finalId = id;
        calcolaPrezzoFinaleButton.addActionListener(new ActionListener() {
            //Ricalcolo del prezzo finale del biglietto
            @Override
            public void actionPerformed(ActionEvent e) {
              dimesione1[0]=0;
              dimesione2[0]=0;

              float prezzoTot = 0;
                DefaultListModel listModel = new DefaultListModel();
                listaPrezzi.setModel(listModel);

                if (seScalo == true) {
                    //Se uno Scalo e' stato selezionato
                    //Stampa delle specifiche dei biglietti
                    if (passegieroAffettoDaDisabilitaCheckBox.isSelected() || LocalDate.now().getYear()-controller.getDataN().getYear()>=65) {
                        listModel.addElement("Prezzo Prima Corsa Ridotto: " + controller.getPrezzo_R(idCorsa));
                        prezzoTot =prezzoTot+ controller.getPrezzo_R(idCorsa);

                        listModel.addElement("Prezzo Seconda Corsa Ridotto: " +controller.getPrezzo_R(idCorsa+1));
                        prezzoTot = prezzoTot+ controller.getPrezzo_R(idCorsa+1);
                    } else {
                        listModel.addElement("Prezzo Prima Corsa : " + controller.getPrezzo_I(idCorsa));
                        prezzoTot =prezzoTot+  controller.getPrezzo_I(idCorsa);
                        listModel.addElement("Prezzo Seconda Corsa : " + controller.getPrezzo_I(idCorsa+1));
                        prezzoTot = prezzoTot+ controller.getPrezzo_I(idCorsa+1);
                    }


                    listModel.addElement("Prezzo Bagagli Prima Corsa : "+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(idCorsa)));
                    prezzoTot=prezzoTot+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(idCorsa));
                    listModel.addElement("Prezzo Bagagli Seconda Corsa : "+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(idCorsa+1)));
                    prezzoTot=prezzoTot+(Float.valueOf(comboBoxB.getSelectedItem().toString())*controller.getSovraprezzo_BCorsa(idCorsa+1));

                    if(finalPrenotazion ==true){
                        listModel.addElement("Tassa Prenotazione Prima Corsa : "+controller.getSovraprezzo_PCorsa(idCorsa));
                        prezzoTot=prezzoTot+controller.getSovraprezzo_PCorsa(idCorsa);
                        listModel.addElement("Tassa Prenotazione Seconda Corsa : "+controller.getSovraprezzo_PCorsa(idCorsa+1));
                        prezzoTot=prezzoTot+controller.getSovraprezzo_PCorsa(idCorsa+1);
                    }

                } else {
                    //Se la Corsa e' Diretta
                    //Stampa delle specifiche dell biglietto
                    if (passegieroAffettoDaDisabilitaCheckBox.isSelected() || LocalDate.now().getYear()-controller.getDataN().getYear()>=65) {
                        listModel.addElement("Prezzo Corsa Ridotto : " + controller.getPrezzo_R(finalId));
                        prezzoTot = prezzoTot + controller.getPrezzo_R(finalId);
                    } else {
                        listModel.addElement("Prezzo corsa : " + controller.getPrezzo_I(finalId));
                        prezzoTot = prezzoTot + controller.getPrezzo_I(finalId);
                    }

                    listModel.addElement("Prezzo Bagagli : "+(Float.valueOf(comboBoxB.getSelectedItem().toString()) * controller.getSovraprezzo_BCorsa(finalId)));
                    prezzoTot = prezzoTot + (Float.valueOf(comboBoxB.getSelectedItem().toString()) * controller.getSovraprezzo_BCorsa(finalId));

                    if(finalPrenotazion ==true){
                        listModel.addElement("Tassa Prenotazione : "+controller.getSovraprezzo_PCorsa(finalId));
                        prezzoTot=prezzoTot+controller.getSovraprezzo_PCorsa(finalId);
                    }
                }

                //Se il Natante e' un Tragetto
                if (!(comboBoxAutoveiclo.getSelectedItem().equals("Autoveicolo non trasportato da Natante")||
                        comboBoxAutoveiclo.getSelectedItem().equals("Nessun Autoveicolo disponibile"))) {

                    if (seScalo == false){
                    for (int i = 0; i<controller.GrandeZZAArreyAutoveicliCorsa(finalId); i++) {
                        if (controller.getTipoAutoVCorsa(finalId, i).equals(comboBoxAutoveiclo.getSelectedItem().toString())) {
                            listModel.addElement("Prezzo " + comboBoxAutoveiclo.getSelectedItem().toString() + " : " + controller.getSovraprezzo_ACorsa(finalId, i));
                            prezzoTot = prezzoTot + controller.getSovraprezzo_ACorsa(finalId,i);
                        }
                    }}
                    if (seScalo == true ) {
                    for (int i = 0; i<controller.GrandeZZAArreyAutoveicliCorsa(idCorsa); i++) {
                        if(controller.getTipoAutoVCorsa(idCorsa,i).equals(comboBoxAutoveiclo.getSelectedItem().toString())) {
                            listModel.addElement("Prezzo Prima Corsa : " + comboBoxAutoveiclo.getSelectedItem().toString() + " : " + controller.getSovraprezzo_ACorsa(idCorsa, i));
                            prezzoTot = prezzoTot + controller.getSovraprezzo_ACorsa(idCorsa, i);
                            dimesione1[0] = controller.getDimensioneCorsa(idCorsa, i);
                            for (int j = 0; j < controller.GrandeZZAArreyAutoveicliCorsa(idCorsa + 1); j++) {
                                if (controller.getTipoAutoVCorsa(idCorsa, i).equals(controller.getTipoAutoVCorsa(idCorsa + 1, j))) {
                                    listModel.addElement("Prezzo Seconda Corsa : " + comboBoxAutoveiclo.getSelectedItem().toString() + " : " + controller.getSovraprezzo_ACorsa(idCorsa + 1, j));
                                    prezzoTot = prezzoTot + controller.getSovraprezzo_ACorsa(idCorsa + 1, j);
                                    dimesione2[0] = controller.getDimensioneCorsa(idCorsa + 1, j);
                                }
                            }
                        }
                        }
                    }

                }

                listModel.addElement("Tasse di commisione : " + String.format("%.2f", prezzoTot * 0.014));
                prezzoTot = (float) (prezzoTot + (prezzoTot * 0.014));
                listModel.addElement("------------------------------------------------------------------------");
                listModel.addElement("");
                listModel.addElement("Prezzo Totale : " + String.format("%.2f", prezzoTot));

            }
        });
        confermaAquistoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //Controllo di posti disponibili nelle due corse dello scalo
                if(seScalo==true && controller.getPostirimasti_P(idCorsa)>0 && controller.getPostirimasti_P(idCorsa+1)>0) {
                        if(controller.getPostirimasti_A(idCorsa)>=dimesione1[0] && controller.getPostirimasti_A(idCorsa+1)>=dimesione2[0]){

                            //Inserimento di Biglietto Prima Corsa

                    String erorr=controller.InserisciBiglietto(idCorsa,Integer.valueOf(comboBoxB.getSelectedItem().toString()),comboBoxAutoveiclo.getSelectedItem().toString(),passegieroAffettoDaDisabilitaCheckBox.isSelected(),finalPrenotazion);
                    System.out.println(erorr);
                    if(!erorr.equals("")){
                        JOptionPane.showMessageDialog(null,erorr);
                    }else {

                        //Inserimento di Biglietto seconda corsa

                        erorr = controller.InserisciBiglietto(idCorsa+1, Integer.valueOf(comboBoxB.getSelectedItem().toString()), comboBoxAutoveiclo.getSelectedItem().toString(), passegieroAffettoDaDisabilitaCheckBox.isSelected(), finalPrenotazion);
                        System.out.println(erorr);
                        if (erorr.equals("")) {
                            JOptionPane.showMessageDialog(null, "Biglietti Prenotato");
                            //Torna a l'interfaccia Cliente
                            CliInterface interFaccia=new CliInterface(original,controller);
                            interFaccia.frame.setVisible(true);
                            frameChiamante.dispose();
                            frame.dispose();
                        } else {
                            JOptionPane.showMessageDialog(null, erorr, null, JOptionPane.OK_OPTION, UIManager.getIcon("OptionPane.errorIcon"));
                        }
                    }

                }else{
                            JOptionPane.showMessageDialog(null,"Posti "+comboBoxAutoveiclo.getSelectedItem().toString()+" Non disponibili ");
                        }
                }else if(seScalo==true) {
                    JOptionPane.showMessageDialog(null,"Posti Esauriti : ci dispiace per l'inconvegnente ");

                }

                if (seScalo==false){

                    //Inserimento di Biglietto
                    String erorr = controller.InserisciBiglietto(finalId, Integer.valueOf(comboBoxB.getSelectedItem().toString()), comboBoxAutoveiclo.getSelectedItem().toString(), passegieroAffettoDaDisabilitaCheckBox.isSelected(), finalPrenotazion);
                    if (erorr.equals("")) {
                        JOptionPane.showMessageDialog(null, "Biglietto Prenotato");
                        //Torna a l'interfaccia Cliente
                        CliInterface interFaccia=new CliInterface(original,controller);
                        interFaccia.frame.setVisible(true);
                        frameChiamante.dispose();
                        frame.dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, erorr,null,JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                    }
                }
            }
        });


        tornaASelezioneButton.addActionListener(new ActionListener() {
            //Torna alla selezione delle corse
            @Override
            public void actionPerformed(ActionEvent e) {
                frameChiamante.setVisible(true);
                frame.dispose();
                comboBoxAutoveiclo.removeAllItems();
            }
        });
    }
}
