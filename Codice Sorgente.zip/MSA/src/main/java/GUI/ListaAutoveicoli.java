package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The type Lista autoveicoli.
 */
public class ListaAutoveicoli {
    /**
     * The Frame.
     */
    public JFrame frame;
    private JComboBox comboBoxAutoveicoli;
    private JList listAutoveicoli;
    private JButton visualizzaSpecifice;
    private JButton aggiungiButton;
    private JButton eliminaButton;
    private JButton modificaButton;
    private JButton backButton;
    private JPanel panelAutoV;


    /**
     * Instantiates a new Lista autoveicoli.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public ListaAutoveicoli(JFrame frameChiamante , Controller controller){

        frame = new JFrame("ListaAutoveicoli");
        frame.setContentPane(panelAutoV);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        /** il metodo autoVeicoliComp seleziona tutti gli autoveicoli
         *  che gestisce la compagnia che ha fatto il login */

        String erorr= controller.autoVeicoliComp();
        if(erorr.equals("")) {
            for (int i = 0; i < controller.GrandeZZAArreyAutoveicli(); i++) {
                comboBoxAutoveicoli.addItem(controller.getTipoAutoV(i));
            }
        }else {
            JOptionPane.showMessageDialog(null,erorr);
        }

        /** questo pulsante visualizza a schermo le specifiche di un autoveicolo
         *  selezionato dalla compagnia */

        visualizzaSpecifice.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultListModel listModel = new DefaultListModel();
                listAutoveicoli.setModel(listModel);
                for (int i=0 ;i<controller.GrandeZZAArreyAutoveicli();i++){
                    if(comboBoxAutoveicoli.getSelectedItem().equals(controller.getTipoAutoV(i))){
                        listModel.addElement("Tipo : "+controller.getTipoAutoV(i));
                        listModel.addElement("Sovraprezzo Autoveicoli : "+controller.getSovraprezzo_A(i));
                        listModel.addElement("Dimensione : "+controller.getDimensione(i));
                    }
                }

            }
        });

        /** questo pulsante permette di modificare il prezzo
         *  e la dimensione di un autoveicolo selezionato dalla compagnia */

        modificaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String prezzoA = JOptionPane.showInputDialog("Inserire Prezzo "+comboBoxAutoveicoli.getSelectedItem()+"  : ");
                String dimensione = JOptionPane.showInputDialog("Inserire Dimensione "+comboBoxAutoveicoli.getSelectedItem()+"  : ");
                Float prezzoAuto;
                Integer dimensioneA;
                try {
                    prezzoAuto = Float.valueOf(prezzoA);
                    if (prezzoAuto <=0) throw new Exception();
                    dimensioneA = Integer.valueOf(dimensione);
                    if (dimensioneA <= 0) throw new Exception();
                } catch (Exception exception) {
                    prezzoAuto = null;
                    dimensioneA = null;
                    JOptionPane.showMessageDialog(null, "Prezzo non valido");
                }

                /** il metodo updateVeicolo modifica sul database le specifiche del veicolo selezionato */

                if (prezzoAuto != null && dimensioneA != null) {
                    String erorr = controller.updateAutoVeicolo(comboBoxAutoveicoli.getSelectedItem().toString(),prezzoAuto,dimensioneA);
                    if (erorr.equals("")) {
                        JOptionPane.showMessageDialog(null, "Autoveicolo modificato");
                        controller.SvuotaArreyAutoVeicoli();
                        frameChiamante.setVisible(true);
                        frame.dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, erorr);
                    }

                }
            }
        });

        eliminaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object[] opzioi = {"Elimina AutoVeicolo : "+comboBoxAutoveicoli.getSelectedItem(), "Anulla"};
                controller.SvuotaArreyCor();
                frame.setSize(1000,600);
                JOptionPane.setDefaultLocale(null);
                int opzioni = JOptionPane.showOptionDialog(panelAutoV, "Azzenzione Eliminazione Autoveicolo", "Selzione ", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opzioi, opzioi[0]);
                if (opzioni == 0) {

                    /** il metodo eliminaAutoveicolo elimina dal database il veicolo selezionato */

                    String erorr = controller.eliminaAutoveicolo(comboBoxAutoveicoli.getSelectedItem().toString());
                    if (erorr.equals("")) {
                        JOptionPane.showMessageDialog(null, "Autoveicolo Eliminato");
                        controller.SvuotaArreyAutoVeicoli();
                        frameChiamante.setVisible(true);
                        frame.dispose();
                    }else {
                      JOptionPane.showMessageDialog(null, erorr);
                    }
                }
            }
        });

      aggiungiButton.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
              String tipoAuto = JOptionPane.showInputDialog("Inserire Nome della Tipologia di Autoveicolo : ");
              String prezzoA = JOptionPane.showInputDialog("Inserire Prezzo  : ");
              String dimensione = JOptionPane.showInputDialog("Inserire Dimensione : ");

              Float prezzoAuto;
              Integer dimensioneA;
              try {
                  prezzoAuto = Float.valueOf(prezzoA);
                  if (prezzoAuto <=0) throw new Exception();
                  dimensioneA = Integer.valueOf(dimensione);
                  if (dimensioneA <= 0) throw new Exception();
              } catch (Exception exception) {
                  prezzoAuto = null;
                  dimensioneA = null;
                  JOptionPane.showMessageDialog(null, "Prezzo non valido");
              }
              if (prezzoAuto != null && dimensioneA != null) {

                  Object[] opzioi = {"Aggiungiere AutoVeicolo : " + tipoAuto, "Anulla"};
                  JOptionPane.setDefaultLocale(null);

                  int opzioni = JOptionPane.showOptionDialog(panelAutoV, "Dimensione :" + dimensione +
                          "\nPrezzo Autoveicolo : " + prezzoA, "Selzione ", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opzioi, opzioi[0]);
                    if(opzioni==0){

                       String erorr=controller.addAutoveicolo(tipoAuto.toLowerCase(),prezzoAuto,dimensioneA);

                       if (erorr.equals("")) {
                            JOptionPane.showMessageDialog(null, "Autoveicolo Aggiunto");
                            controller.SvuotaArreyAutoVeicoli();
                            frameChiamante.setVisible(true);
                            frame.dispose();
                        }else {
                           JOptionPane.showMessageDialog(null, erorr);
                       }

                    }

              }
          }
      });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.SvuotaArreyAutoVeicoli();
                frameChiamante.setVisible(true);
                frame.dispose();
            }
        });

    }
}
