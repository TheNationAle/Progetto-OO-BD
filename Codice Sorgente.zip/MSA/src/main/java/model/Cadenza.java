package model;

import java.util.ArrayList;
import java.util.Date;

/**
 * The type Cadenza.
 */
public class Cadenza {
    private int id_cad;
    private String giorni;
    private Date  periodo_I;
    private Date  periodo_F;
    private ArrayList<Corsa> corse =new ArrayList<Corsa>();

    /**
     * Instantiates a new Cadenza.
     *
     * @param id_cad    the id cad
     * @param giorni    the giorni
     * @param periodo_I the periodo i
     * @param periodo_F the periodo f
     */
    public Cadenza(int id_cad, String giorni, Date periodo_I, Date periodo_F) {
        this.id_cad = id_cad;
        this.giorni = giorni;
        this.periodo_I = periodo_I;
        this.periodo_F = periodo_F;
    }

    /**
     * Instantiates a new Cadenza.
     *
     * @param giorni    the giorni
     * @param periodo_I the periodo i
     * @param periodo_F the periodo f
     */
    public Cadenza(String giorni, Date periodo_I, Date periodo_F) {
        this.giorni = giorni;
        this.periodo_I = periodo_I;
        this.periodo_F = periodo_F;
    }

    /**
     * Gets giorni.
     *
     * @return the giorni
     */
    public String getGiorni() {
        return giorni;
    }

    /**
     * Sets giorni.
     *
     * @param giorni the giorni
     */
    public void setGiorni(String giorni) {
        this.giorni = giorni;
    }

    /**
     * Gets periodo i.
     *
     * @return the periodo i
     */
    public Date getPeriodo_I() {
        return periodo_I;
    }

    /**
     * Sets periodo i.
     *
     * @param periodo_I the periodo i
     */
    public void setPeriodo_I(Date periodo_I) {
        this.periodo_I = periodo_I;
    }

    /**
     * Gets periodo f.
     *
     * @return the periodo f
     */
    public Date getPeriodo_F() {
        return periodo_F;
    }

    /**
     * Sets periodo f.
     *
     * @param periodo_F the periodo f
     */
    public void setPeriodo_F(Date periodo_F) {
        this.periodo_F = periodo_F;
    }

    /**
     * Gets corse.
     *
     * @return the corse
     */
    public ArrayList<Corsa> getCorse() {
        return corse;
    }

    /**
     * Gets id cad.
     *
     * @return the id cad
     */
    public int getId_cad() {
        return id_cad;
    }

    /**
     * Sets id cad.
     *
     * @param id_cad the id cad
     */
    public void setId_cad(int id_cad) {
        this.id_cad = id_cad;
    }
}
