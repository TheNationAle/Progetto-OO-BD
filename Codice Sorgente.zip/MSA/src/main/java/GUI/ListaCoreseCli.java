package GUI;

import Controller.Controller;

import javax.swing.*;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;


/**
 * The type Lista corese cli.
 */
public class ListaCoreseCli {

    /**
     * The Frame.
     */
    public JFrame frame;
    private JPanel listaCoreseCli;
    private JTable corse;
    private JButton buttonCorse;
    private JTextField portoP;
    private JLabel portop;
    private JTextField textField2;
    private JLabel portoA;
    private JTextField dataPart;
    private JLabel datap;
    private JLabel orarioP;
    private JScrollPane jScroll;
    private JComboBox comboPortP;
    private JComboBox comboPortiA;
    private JSpinner ora;
    private JSpinner minuti;
    private JButton filterButton;
    private JButton intarfaceButton;

    private JButton selezionaCorsaButton;
    private JLabel labaelSelectid;
    private JComboBox comboBoxCors;
    private JSlider sliderPrezzo;
    private JComboBox comboBoxTipoNat;
    private JLabel sliderPrezzoMax;
    private JLabel textNatSelex;


    /**
     * Instantiates a new Lista corese cli.
     *
     * @param frameChiamante the frame chiamante
     * @param frameOriginale the frame originale
     * @param controller     the controller
     */
    public ListaCoreseCli(JFrame frameChiamante,JFrame frameOriginale, Controller controller) {

        jScroll.setVisible(false);
        frame = new JFrame("ListaCoreseCli");
        frame.setContentPane(listaCoreseCli);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        filterButton.setVisible(false);

        comboBoxCors.setVisible(false);
        selezionaCorsaButton.setVisible(false);
        labaelSelectid.setVisible(false);

        final boolean[] isScalo = {false};

        controller.PortiEsistenti();
        for(int i = 0; i <controller.GrandeZZAArreyPort(); i++){
            comboPortP.addItem(controller.getNomePorti(i));
            comboPortiA.addItem(controller.getNomePorti(i));
        }
        comboPortiA.setSelectedItem(comboPortP.getItemAt(comboPortiA.getItemCount()-1));

        comboBoxTipoNat.addItem("Nessuna Preferenza");
        comboBoxTipoNat.addItem("Traghetto");
        comboBoxTipoNat.addItem("Motonave");
        comboBoxTipoNat.addItem("Aliscafo");

        dataPart.setText(String.valueOf(LocalDate.now()));

        /** Inizalizzazione degli spinner per linserimento dell orario desiderato con limiti di 23 e 59 rispettivamente
         * per Ore e Minuti */
        SpinnerNumberModel numberModelOra = new SpinnerNumberModel();
        SpinnerNumberModel numberModelMin = new SpinnerNumberModel();


        numberModelOra.setMaximum(23);
        numberModelOra.setMinimum(0);
        ora.setModel(numberModelOra);
        /**Impediamo l'inserimento di dati al di furoti dei parametri posti */
        ora.addKeyListener(new KeyListener() {
        @Override
        public void keyTyped(KeyEvent e) {
        e.consume();
        }

        @Override
        public void keyPressed(KeyEvent e) {
        e.consume();
        }

        @Override
        public void keyReleased(KeyEvent e) {
        e.consume();
        }
         });

        numberModelMin.setMaximum(59);
        numberModelMin.setMinimum(0);
        minuti.setModel(numberModelMin);
        minuti.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                e.consume();
            }
        });

        /** bottone per ricercare la corsa con i parametri inseriti*/
        buttonCorse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    //Conversione Stringa della Data in LocalDate
                    String dateInString = dataPart.getText();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ITALIAN);
                    LocalDate dateTime = LocalDate.parse(dateInString, formatter);

                    //Controllo di data inserita non passata
                    if (!dataPart.getText().equals("") && (dateTime.isAfter(LocalDate.now()) || dateTime.isEqual(LocalDate.now()))) {
                      //Controllo Porti inseriti distinti
                        if (!comboPortP.getSelectedItem().toString().equals(comboPortiA.getSelectedItem().toString())) {
                            String temp;

                            if (10 > (int) ora.getValue() && 10 > (int) minuti.getValue()) {
                                temp = "0" + ora.getValue().toString() + ":0" + minuti.getValue().toString();

                            } else if (10 > (int) minuti.getValue()) {
                                temp = ora.getValue().toString() + ":0" + minuti.getValue().toString();

                            } else if (10 > (int) ora.getValue()) {
                                temp = "0" + ora.getValue().toString() + ":" + minuti.getValue().toString();

                            } else {
                                temp = ora.getValue().toString() + ":" + minuti.getValue().toString();
                            }


                            DateTimeFormatter formatTempP = DateTimeFormatter.ofPattern("HH:mm", Locale.ITALY);
                            LocalTime timeP = LocalTime.parse(temp, formatTempP);

                            if((timeP.compareTo(LocalTime.now())>=0) && dateTime.isEqual(LocalDate.now()) || dateTime.isAfter(LocalDate.now())) {
                                //clear dell ArreyList per assicurare nessuno dato sporco
                                controller.SvuotaArreyCor();
                                int prezzoSql = sliderPrezzo.getValue();
                                if (sliderPrezzo.getValue() >= sliderPrezzo.getMaximum()) {
                                    prezzoSql = 99999;
                                }
                                //Ricaviamo le corse disponibili
                                String erorr = controller.CercaCorse(comboPortP.getSelectedItem().toString(), comboPortiA.getSelectedItem().toString(), dateTime, timeP, prezzoSql);
                                if (!erorr.equals("")) {

                                    isScalo[0] = false;

                                    /**Se le corse sono state trovate rendiamo invissibile nell'interfaccia i campi di filtrazione e rediamo visibile
                                     * l'eventale tabella di corse con opzioni di selezione */

                                    frame.setSize(1400, 600);
                                    frame.setLocationRelativeTo(null);
                                    jScroll.setVisible(true);
                                    buttonCorse.setVisible(false);

                                    intarfaceButton.setVisible(false);
                                    filterButton.setVisible(true);

                                    portoA.setVisible(false);
                                    orarioP.setVisible(false);
                                    portop.setVisible(false);
                                    datap.setVisible(false);

                                    comboPortP.setVisible(false);
                                    comboPortiA.setVisible(false);
                                    dataPart.setVisible(false);
                                    ora.setVisible(false);
                                    minuti.setVisible(false);

                                    comboBoxCors.setVisible(true);
                                    selezionaCorsaButton.setVisible(true);
                                    labaelSelectid.setVisible(true);

                                    sliderPrezzo.setVisible(false);
                                    comboBoxTipoNat.setVisible(false);
                                    textNatSelex.setVisible(false);
                                    sliderPrezzoMax.setVisible(false);


                                    corse.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

                                    DefaultTableModel tabelModel = new DefaultTableModel(new Object[][]{}, new String[]{"ID", "Porto Partenza", "Porto D'Arrivo", "Data", "Orario Partenza", "Orario Arrivo ", "Tipo", "Prezzo", "Operata da"}) {
                                        //Preveniamo la modifica dei dati nella tabella
                                        @Override
                                        public boolean isCellEditable(int row, int column) {
                                            return false;
                                        }
                                    };

                                    corse.setEnabled(true);
                                    corse.setModel(tabelModel);
                                    corse.getTableHeader().setReorderingAllowed(false);
                                    /**ciclo di inserimento delle corse nella tabella
                                     * Controllo di Natante selezionato
                                     * Controllo di eventuali ritardi Segnalati per la corsa*/
                                    for (int i = tabelModel.getRowCount(); i < controller.GrandeZZAArreyCors(); i++) {
                                        if (comboBoxTipoNat.getSelectedItem().toString().equals(controller.getTipoNatCliente(i)) || comboBoxTipoNat.getSelectedItem().toString().equals(comboBoxTipoNat.getItemAt(0).toString())) {
                                            if (controller.getRitardo(i) != 0) {
                                                tabelModel.addRow(new Object[]{controller.getId_corsa(i), controller.getPorto_P(i), controller.getPorto_A(i), controller.getData(i),
                                                        controller.getOrario_P(i) + " Ritardo Segnalato : " + controller.getRitardo(i), controller.getOrario_A(i), controller.getTipoNatCorsa(i), controller.getPrezzo_I(i), controller.getNomeCompagniaCorsa(i)});


                                            } else {
                                                tabelModel.addRow(new Object[]{controller.getId_corsa(i), controller.getPorto_P(i), controller.getPorto_A(i), controller.getData(i),
                                                        controller.getOrario_P(i), controller.getOrario_A(i), controller.getTipoNatCorsa(i), controller.getPrezzo_I(i), controller.getNomeCompagniaCorsa(i)});
                                            }
                                            comboBoxCors.addItem(controller.getId_corsa(i));
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Corsa diretta Trovata " +
                                                    "\n Natante selezionato non Disponibile");
                                            controller.SvuotaArreyCor();
                                            frame.setSize(1000, 600);
                                            frame.setLocationRelativeTo(null);

                                            portoA.setVisible(true);
                                            orarioP.setVisible(true);
                                            portop.setVisible(true);
                                            datap.setVisible(true);

                                            comboPortP.setVisible(true);
                                            comboPortiA.setVisible(true);
                                            dataPart.setVisible(true);
                                            ora.setVisible(true);
                                            minuti.setVisible(true);
                                            controller.SvuotaArreyCor();
                                            jScroll.setVisible(false);
                                            buttonCorse.setVisible(true);
                                            filterButton.setVisible(false);
                                            intarfaceButton.setVisible(true);

                                            comboBoxCors.setVisible(false);
                                            selezionaCorsaButton.setVisible(false);
                                            labaelSelectid.setVisible(false);
                                            comboBoxCors.setVisible(false);


                                            sliderPrezzo.setVisible(true);
                                            comboBoxTipoNat.setVisible(true);
                                            textNatSelex.setVisible(true);
                                            sliderPrezzoMax.setVisible(true);


                                            comboBoxCors.removeAllItems();

                                        }
                                    }


                                } else {
                                    //Mesaggio di scelta per la ricerca di Scali
                                    Object[] opzioi = {"Cerca scali disponibli", "Torna alla ricerca"};
                                    controller.SvuotaArreyCor();
                                    JOptionPane.setDefaultLocale(null);
                                    int opzioni = JOptionPane.showOptionDialog(listaCoreseCli, "Nessuna Corsa trovata", "Selzione ", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE, null, opzioi, opzioi[0]);

                                    if (opzioni == 0) {
                                        /**Ricerca Scali*/

                                        isScalo[0] = true;
                                        controller.SvuotaArreyCor();
                                        /**funzione che ricava eventali corse con 1 scalo con un minimo di 15 minuti di intervallo+eventuali ruitardi gia segnalati per la corsa
                                         * e un massimo di 3 ore di scalo*/
                                        erorr = controller.CercaCorseScalo(comboPortP.getSelectedItem().toString(), comboPortiA.getSelectedItem().toString(), dateTime, timeP);
                                        if (!erorr.equals("")) {

                                            //Scalo Trovato
                                            /**Se le corse sono state trovate rendiamo invissibile nell'interfaccia i campi di filtrazione e rediamo visibile
                                             * l'eventale tabella di corse con opzioni di selezione */
                                            frame.setSize(1400, 600);
                                            frame.setLocationRelativeTo(null);
                                            jScroll.setVisible(true);
                                            buttonCorse.setVisible(false);

                                            intarfaceButton.setVisible(false);
                                            filterButton.setVisible(true);

                                            portoA.setVisible(false);
                                            orarioP.setVisible(false);
                                            portop.setVisible(false);
                                            datap.setVisible(false);

                                            comboPortP.setVisible(false);
                                            comboPortiA.setVisible(false);
                                            dataPart.setVisible(false);
                                            ora.setVisible(false);
                                            minuti.setVisible(false);

                                            selezionaCorsaButton.setVisible(true);
                                            comboBoxCors.setVisible(true);

                                            sliderPrezzo.setVisible(false);
                                            comboBoxTipoNat.setVisible(false);
                                            textNatSelex.setVisible(false);
                                            sliderPrezzoMax.setVisible(false);


                                            corse.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                                            DefaultTableModel tabelModel = new DefaultTableModel(new Object[][]{}, new String[]{"ID Scalo", "Prima Corsa", "Seconda Corsa", "Date", "Orario prima Corsa", "Orario seconda Corsa ", "Imbarcazione", "Prezzo Totale", "Operata da"}) {
                                                @Override
                                                public boolean isCellEditable(int row, int column) {
                                                    return false;
                                                }
                                            };
                                            corse.setModel(tabelModel);
                                            corse.setEnabled(true);
                                            corse.setDragEnabled(false);
                                            corse.getTableHeader().setReorderingAllowed(false);
                                            int j = 0;
                                            /**Ciclo di inserimento nella tabella
                                             * Controllo di Natante selezionato e Eventuali Ritardi per entrambe le corse
                                             * indice delle corse gestito internamente con aritmetica (i-1)x2 */
                                            for (int i = 0; i < controller.GrandeZZAArreyCors(); i = i + 2) {
                                                j = i + 1;
                                                if (comboBoxTipoNat.getSelectedItem().toString().equals(controller.getTipoNatCorsa(i)) && comboBoxTipoNat.getSelectedItem().toString().equals(controller.getTipoNatCorsa(j))
                                                        || comboBoxTipoNat.getSelectedItem().toString().equals(comboBoxTipoNat.getItemAt(0).toString())) {

                                                    if (controller.getRitardo(i) != 0 && controller.getRitardo(j) != 0) {
                                                        tabelModel.addRow(new Object[]{tabelModel.getRowCount() + 1, controller.getPorto_P(i) + "-" + controller.getPorto_P(j), controller.getPorto_A(i) + "-" + controller.getPorto_A(j), controller.getData(i) + " | | " + controller.getData(j),
                                                                controller.getOrario_P(i) + "-" + controller.getOrario_A(i) + "" +
                                                                        "\n Ritardo " + controller.getRitardo(i),
                                                                controller.getOrario_P(i) + "-" + controller.getOrario_A(j) +
                                                                        " Ritardo " + controller.getRitardo(j), controller.getTipoNatCorsa(i) + "-" + controller.getTipoNatCorsa(i),
                                                                (controller.getPrezzo_I(i) + controller.getPrezzo_I(j)),
                                                                controller.getNomeCompagniaCorsa(i) + "/" + controller.getNomeCompagniaCorsa(j)});

                                                        comboBoxCors.addItem(tabelModel.getRowCount());

                                                    } else if (controller.getRitardo(i) != 0) {
                                                        tabelModel.addRow(new Object[]{tabelModel.getRowCount() + 1, controller.getPorto_P(i) + "-" + controller.getPorto_P(j), controller.getPorto_A(i) + "-" + controller.getPorto_A(j), controller.getData(i) + " | | " + controller.getData(j),
                                                                controller.getOrario_P(i) + "-" + controller.getOrario_A(i) + " " +
                                                                        "\n Ritardo " + controller.getRitardo(i),
                                                                controller.getOrario_P(i) + "-" + controller.getOrario_A(j), controller.getTipoNatCorsa(i) + "-" + controller.getTipoNatCorsa(i),
                                                                (controller.getPrezzo_I(i) + controller.getPrezzo_I(j)),
                                                                controller.getNomeCompagniaCorsa(i) + "/" + controller.getNomeCompagniaCorsa(j)});
                                                        comboBoxCors.addItem(tabelModel.getRowCount());

                                                    } else if (controller.getRitardo(j) != 0) {
                                                        tabelModel.addRow(new Object[]{tabelModel.getRowCount() + 1, controller.getPorto_P(i) + "-" + controller.getPorto_P(j), controller.getPorto_A(i) + "-" + controller.getPorto_A(j), controller.getData(i) + " | | " + controller.getData(j),
                                                                controller.getOrario_P(i) + "-" + controller.getOrario_A(i), controller.getOrario_P(i) + "-" + controller.getOrario_A(j) + " " +
                                                                "\nRitardo " + controller.getRitardo(j) + "'", controller.getTipoNatCorsa(i) + "-" + controller.getTipoNatCorsa(i),
                                                                (controller.getPrezzo_I(i) + controller.getPrezzo_I(j)),
                                                                controller.getNomeCompagniaCorsa(i) + "/" + controller.getNomeCompagniaCorsa(j)});

                                                        comboBoxCors.addItem(tabelModel.getRowCount());

                                                    } else {
                                                        tabelModel.addRow(new Object[]{tabelModel.getRowCount() + 1, controller.getPorto_P(i) + "-" + controller.getPorto_P(j), controller.getPorto_A(i) + "-" + controller.getPorto_A(j), controller.getData(i) + " | | " + controller.getData(j),
                                                                controller.getOrario_P(i) + "-" + controller.getOrario_A(i),
                                                                controller.getOrario_P(i) + "-" + controller.getOrario_A(j), controller.getTipoNatCorsa(i) + "-" + controller.getTipoNatCorsa(i),
                                                                (controller.getPrezzo_I(i) + controller.getPrezzo_I(j)),
                                                                controller.getNomeCompagniaCorsa(i) + "/" + controller.getNomeCompagniaCorsa(j)});

                                                        comboBoxCors.addItem(tabelModel.getRowCount());
                                                    }

                                                }
                                            }
                                            if (tabelModel.getRowCount() == 0) {
                                                //Scali torvati ma non del Natante Desiderato
                                                JOptionPane.showMessageDialog(null, "Nessuna corsa trovata");
                                                controller.SvuotaArreyCor();
                                                frame.setSize(1000, 600);
                                                frame.setLocationRelativeTo(null);

                                                portoA.setVisible(true);
                                                orarioP.setVisible(true);
                                                portop.setVisible(true);
                                                datap.setVisible(true);

                                                comboPortP.setVisible(true);
                                                comboPortiA.setVisible(true);
                                                dataPart.setVisible(true);
                                                ora.setVisible(true);
                                                minuti.setVisible(true);

                                                jScroll.setVisible(false);
                                                controller.SvuotaArreyCor();
                                                buttonCorse.setVisible(true);
                                                filterButton.setVisible(false);
                                                intarfaceButton.setVisible(true);
                                                selezionaCorsaButton.setVisible(false);

                                                sliderPrezzo.setVisible(true);
                                                comboBoxTipoNat.setVisible(true);
                                                comboBoxCors.setVisible(false);

                                                textNatSelex.setVisible(true);
                                                sliderPrezzoMax.setVisible(true);

                                            }

                                        } else {
                                            //Riga 259
                                            //Nessun Scalo trovato
                                            JOptionPane.showMessageDialog(null, "Nessuna corsa trovata");
                                            frame.setSize(1000, 600);
                                            frame.setLocationRelativeTo(null);

                                            portoA.setVisible(true);
                                            orarioP.setVisible(true);
                                            portop.setVisible(true);
                                            datap.setVisible(true);

                                            comboPortP.setVisible(true);
                                            comboPortiA.setVisible(true);
                                            dataPart.setVisible(true);
                                            ora.setVisible(true);
                                            minuti.setVisible(true);

                                            jScroll.setVisible(false);
                                            controller.SvuotaArreyCor();
                                            buttonCorse.setVisible(true);
                                            filterButton.setVisible(false);
                                            intarfaceButton.setVisible(true);

                                            sliderPrezzo.setVisible(true);
                                            comboBoxTipoNat.setVisible(true);
                                            comboBoxCors.setVisible(false);
                                            textNatSelex.setVisible(true);
                                            sliderPrezzoMax.setVisible(true);

                                        }


                                    }
                                    // riga 251
                                    if (opzioni == 1) {
                                        //Ricerca Scali non desiderata

                                        frame.setSize(1000, 600);
                                        frame.setLocationRelativeTo(null);

                                        portoA.setVisible(true);
                                        orarioP.setVisible(true);
                                        portop.setVisible(true);
                                        datap.setVisible(true);

                                        comboPortP.setVisible(true);
                                        comboPortiA.setVisible(true);
                                        dataPart.setVisible(true);
                                        ora.setVisible(true);
                                        minuti.setVisible(true);

                                        jScroll.setVisible(false);
                                        controller.SvuotaArreyCor();
                                        buttonCorse.setVisible(true);
                                        filterButton.setVisible(false);
                                        intarfaceButton.setVisible(true);
                                        comboBoxCors.setVisible(false);


                                        sliderPrezzo.setVisible(true);
                                        comboBoxTipoNat.setVisible(true);
                                        textNatSelex.setVisible(true);
                                        sliderPrezzoMax.setVisible(true);

                                    }
                                }
                            }else {
                                JOptionPane.showMessageDialog(null, "Orario selezionato non valido","Warning",JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                            }
                        } else {
                            //riga 148
                            JOptionPane.showMessageDialog(null, "Selezionare Porti diversi","Warning",JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                        }
                    } else {
                        //146
                        JOptionPane.showMessageDialog(null, "Inserisci una Data valida","Warning",JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                    }

                }catch (Exception dateTime){
                    //138
                    System.out.println(dateTime.getMessage());
                    JOptionPane.showMessageDialog(null,"Data non valida yyyy-mm-gg","Warning",JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));

                }
            }
        });
        selezionaCorsaButton.addActionListener(new ActionListener() {
            /**Bottone che conferma la corsa o corse selezionate*/
            @Override
            public void actionPerformed(ActionEvent e) {
                int idCorsa=Integer.valueOf(comboBoxCors.getSelectedItem().toString());
                if(isScalo[0]==true){
                    idCorsa=(idCorsa-1)*(2);
                }
                CompraBigliettoCli compB = new CompraBigliettoCli(frame,frameOriginale, controller,idCorsa, isScalo[0]);
                compB.frame.setVisible(true);
                frame.setVisible(false);
            }
        });

        filterButton.addActionListener(new ActionListener() {
            /**ritorna tutti i parametri di Filtrazione visibili
             * e pulendo l'ArreyList di Corse */
            @Override
            public void actionPerformed(ActionEvent e) {

                frame.setSize(1000,600);
                frame.setLocationRelativeTo(null);

                portoA.setVisible(true);
                orarioP.setVisible(true);
                portop.setVisible(true);
                datap.setVisible(true);

                comboPortP.setVisible(true);
                comboPortiA.setVisible(true);
                dataPart.setVisible(true);
                ora.setVisible(true);
                minuti.setVisible(true);
                controller.SvuotaArreyCor();
                jScroll.setVisible(false);
                buttonCorse.setVisible(true);
                filterButton.setVisible(false);
                intarfaceButton.setVisible(true);

                comboBoxCors.setVisible(false);
                selezionaCorsaButton.setVisible(false);
                labaelSelectid.setVisible(false);
                comboBoxCors.setVisible(false);


                sliderPrezzo.setVisible(true);
                comboBoxTipoNat.setVisible(true);
                textNatSelex.setVisible(true);
                sliderPrezzoMax.setVisible(true);


                comboBoxCors.removeAllItems();


                DefaultTableModel model = (DefaultTableModel) corse.getModel();
                model.setRowCount(0);

            }
        });

        intarfaceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //riapre interfaccia cliente con l'aggiornamento dei dati
                CliInterface cliInterface = new CliInterface(frameOriginale,controller);
                cliInterface.frame.setVisible(true);
                frameChiamante.dispose();
                frame.dispose();
            }
        });

}
}
