package model;

import java.util.ArrayList;

/**
 * The type Porto.
 */
public class Porto {
    private String nome;
    private String comune;
    private String cordinate;

    private ArrayList<Corsa>portiCorsArrivi=new ArrayList<>();
    private ArrayList<Corsa>portiCorsPartenze=new ArrayList<>();

    /**
     * Instantiates a new Porto.
     *
     * @param nome      the nome
     * @param comune    the comune
     * @param cordinate the cordinate
     */
    public Porto(String nome, String comune, String cordinate) {
        this.nome = nome;
        this.comune = comune;
        this.cordinate = cordinate;
    }

    /**
     * Gets nome.
     *
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Sets nome.
     *
     * @param nome the nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Gets comune.
     *
     * @return the comune
     */
    public String getComune() {
        return comune;
    }

    /**
     * Sets comune.
     *
     * @param comune the comune
     */
    public void setComune(String comune) {
        this.comune = comune;
    }

    /**
     * Gets cordinate.
     *
     * @return the cordinate
     */
    public String getCordinate() {
        return cordinate;
    }

    /**
     * Sets cordinate.
     *
     * @param cordinate the cordinate
     */
    public void setCordinate(String cordinate) {
        this.cordinate = cordinate;
    }

    /**
     * Gets porti cors arrivi.
     *
     * @return the porti cors arrivi
     */
    public ArrayList<Corsa> getPortiCorsArrivi() {
        return portiCorsArrivi;
    }

    /**
     * Sets porti cors arrivi.
     *
     * @param portiCorsArrivi the porti cors arrivi
     */
    public void setPortiCorsArrivi(ArrayList<Corsa> portiCorsArrivi) {
        this.portiCorsArrivi = portiCorsArrivi;
    }

    /**
     * Gets porti cors partenze.
     *
     * @return the porti cors partenze
     */
    public ArrayList<Corsa> getPortiCorsPartenze() {
        return portiCorsPartenze;
    }

    /**
     * Sets porti cors partenze.
     *
     * @param portiCorsPartenze the porti cors partenze
     */
    public void setPortiCorsPartenze(ArrayList<Corsa> portiCorsPartenze) {
        this.portiCorsPartenze = portiCorsPartenze;
    }
}
