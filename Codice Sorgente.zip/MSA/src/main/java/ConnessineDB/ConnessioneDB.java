package ConnessineDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * The type Connessione db.
 */
public class ConnessioneDB {
        private static ConnessioneDB instance;
    /**
     * The Connection.
     */
    public Connection connection = null;
        private String nome = "postgres";
        private String password = "Password";
        private String url = "jdbc:postgresql://localhost:5432/postgres";
        private String driver = "org.postgresql.Driver";

        private ConnessioneDB() throws SQLException {
            try {
                Class.forName(this.driver);
                this.connection = DriverManager.getConnection(this.url, this.nome, this.password);
            } catch (ClassNotFoundException var2) {
                System.out.println("Database Connection Creation Failed : " + var2.getMessage());
                var2.printStackTrace();
            }

        }

    /**
     * Gets instance.
     *
     * @return the instance
     * @throws SQLException the sql exception
     */
    public static ConnessioneDB getInstance() throws SQLException {
            if (instance == null) {
                instance = new ConnessioneDB();
            } else if (instance.connection.isClosed()) {
                instance = new ConnessioneDB();
            }

            return instance;
        }
    }

