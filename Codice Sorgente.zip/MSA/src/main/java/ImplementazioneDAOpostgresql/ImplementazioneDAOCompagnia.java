package ImplementazioneDAOpostgresql;

import ConnessineDB.ConnessioneDB;
import DAO.DAOComp;
import model.*;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;


/**
 * The type Implementazione dao compagnia.
 */
public class ImplementazioneDAOCompagnia implements DAOComp {
    private Connection connection;

    /**
     * Instantiates a new Implementazione dao compagnia.
     */
    public ImplementazioneDAOCompagnia() {
        try {
            this.connection = ConnessioneDB.getInstance().connection;
        } catch (SQLException var2) {
            var2.printStackTrace();
        }

    }
    @Override
    public Compagnia ControlloCredenzialiComp(Compagnia c) {
        try {
            Statement ControllaCredenziali;
            ControllaCredenziali = connection.createStatement();
            ResultSet rs = ControllaCredenziali.executeQuery("SELECT * FROM compagnia ");
            while (rs.next()) {
                if (rs.getString("email").equals(c.getEmail()) && rs.getString("passwordcomp").equals(c.getPassword())) {
                    c.setNome(rs.getString("nome"));
                    c.setTelefono(rs.getString("telefono"));
                    c.setSocial(rs.getString("social"));
                    c.setSitoWeb(rs.getString("sitoweb"));
                    c.setSovraprezzo_P(rs.getFloat("sovraprezzo_p"));
                    c.setSovraprezzo_B(rs.getFloat("sovraprezzo_b"));

                    return c;
                }

            }
            return null;
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return null;
        }
    }

    @Override
    public void SelectNat(Compagnia comp) {
        try {
            PreparedStatement ControllaCredenziali;
            ControllaCredenziali = connection.prepareStatement("SELECT * FROM natante ");
            ResultSet rs = ControllaCredenziali.executeQuery();
            while (rs.next()) {
                if(comp.getNome().equals(rs.getString("compagnia"))) {
                    comp.FunzioneAddNatante(new Natante(rs.getInt("id_natante"),rs.getInt("capienzap"),
                            rs.getInt("capienzaa"), rs.getString("tipo"),rs.getString("nome"),comp));
                }
            }

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }

    @Override
    public boolean ControlloCorsaPerNat(Natante N) {
        try {
            PreparedStatement ControllaCredenziali;
            ControllaCredenziali = connection.prepareStatement("SELECT * FROM corsa ");
            ResultSet rs = ControllaCredenziali.executeQuery();
            while (rs.next()) {
                if(N.getId_Natante()==rs.getInt("id_natante")) {
                   return true;
                }
            }
            return false;

        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean inUtilizzo(Integer idNatante, LocalDate dataI, LocalDate dataF, String giorni) {

        Boolean flag = false;
        PreparedStatement cadenzaNatante;
        try {
            cadenzaNatante = connection.prepareStatement("SELECT * FROM cadenza WHERE id_cadenza IN (SELECT DISTINCT id_cadenza FROM corsa WHERE id_natante = ?)");
            cadenzaNatante.setInt(1, idNatante);
            ResultSet rs = cadenzaNatante.executeQuery();

            while (rs.next()){

                if(rs.getDate("periodo_i").compareTo(Date.valueOf(dataI.toString())) < 0){

                    if(rs.getDate("periodo_f").compareTo((Date.valueOf(dataI.toString()))) > 0){

                        String[] giorni1 = rs.getString("giorno").split(", ");

                        for (String giorno : giorni1) {
                            if (giorni.contains(giorno)) {
                                flag = true;
                            }
                        }

                    }

                } else if(rs.getDate("periodo_i").compareTo((Date.valueOf(dataF.toString()))) < 0){

                    String[] giorni1 = rs.getString("giorno").split(", ");

                    for (String giorno : giorni1) {
                        if (giorni.contains(giorno)) {
                            flag = true;
                        }
                    }

                }

            }

        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
        }

        return flag;
    }

    @Override
    public String inserisciCorsa(String partenza, String arrivo, LocalDate dataI, LocalDate dataF, String giorni, LocalTime orarioP, LocalTime orarioA, int natante, Float prezzoIntero, Float prezzoRidotto) {

        PreparedStatement inserisciCadenza;
        PreparedStatement inserisciCorsa;
        PreparedStatement postiNatante;
        PreparedStatement ultimaCadenza;

        try {

            inserisciCadenza = connection.prepareStatement("INSERT INTO cadenza(giorno, periodo_i, periodo_f) VALUES (?, ?, ?)");
            inserisciCadenza.setString(1, giorni);
            inserisciCadenza.setDate(2, Date.valueOf(dataI));
            inserisciCadenza.setDate(3, Date.valueOf(dataF));
            inserisciCadenza.executeUpdate();

            postiNatante = connection.prepareStatement("SELECT * FROM natante WHERE id_natante = ?");
            postiNatante.setInt(1, natante);
            ResultSet rsNatante = postiNatante.executeQuery();
            rsNatante.next();

            ultimaCadenza = connection.prepareStatement("SELECT * FROM cadenza ORDER BY id_cadenza DESC");
            ResultSet idCadenza = ultimaCadenza.executeQuery();
            idCadenza.next();

            inserisciCorsa = connection.prepareStatement("INSERT INTO corsa( id_natante, orariop, orarioa, postirimasti_p, postirimasti_a, prezzo_i, prezzo_r, partenza, arrivo, id_cadenza) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            inserisciCorsa.setInt(1, natante);
            inserisciCorsa.setTime(2, Time.valueOf(orarioP));
            inserisciCorsa.setTime(3, Time.valueOf(orarioA));
            inserisciCorsa.setInt(4, rsNatante.getInt("capienzap"));
            inserisciCorsa.setInt(5, rsNatante.getInt("capienzaa"));
            inserisciCorsa.setFloat(6, prezzoIntero);
            inserisciCorsa.setFloat(7, prezzoRidotto);
            inserisciCorsa.setString(8, partenza);
            inserisciCorsa.setString(9, arrivo);
            inserisciCorsa.setInt(10, idCadenza.getInt("id_cadenza"));
            inserisciCorsa.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "Corse create";
    }

    @Override
    public String eliminaNatante(Integer natante) {

        PreparedStatement elimina;

        try {
            elimina = connection.prepareStatement("DELETE FROM natante WHERE id_natante = ?");
            elimina.setInt(1, natante);
            elimina.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "Natante eliminato";
    }

    @Override
    public String modificaNome(Integer natante, String nome) {
        PreparedStatement modifica;

        try {

            modifica = connection.prepareStatement("UPDATE natante SET nome = ? WHERE id_natante = ?");
            modifica.setString(1, nome);
            modifica.setInt(2, natante);
            modifica.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }

        return "Nome del natante modificato";
    }

    @Override
    public String cercaCorseComp(ArrayList<Corsa> corsa, Compagnia comp) {

        PreparedStatement cerca;
        PreparedStatement natante;
        PreparedStatement cadenza;

        try {
            cerca = connection.prepareStatement("SELECT * FROM corsa WHERE id_natante IN (SELECT id_natante FROM natante WHERE compagnia = ? ) AND cancellazione=false  ORDER BY id_corsa");
            cerca.setString(1, comp.getNome());
            ResultSet rs = cerca.executeQuery();

            while (rs.next()){

                natante = connection.prepareStatement("SELECT * FROM natante WHERE id_natante = ?");
                natante.setInt(1, rs.getInt("id_natante"));
                ResultSet rsNat = natante.executeQuery();
                rsNat.next();

                cadenza = connection.prepareStatement("SELECT * FROM cadenza WHERE id_cadenza = ?");
                cadenza.setInt(1, rs.getInt("id_cadenza"));
                ResultSet rsCad = cadenza.executeQuery();
                rsCad.next();

                corsa.add(new Corsa(rs.getInt("id_corsa"), rs.getDate("data"), rs.getTime("orariop"),
                        rs.getTime("orarioa"), rs.getFloat("prezzo_i"), rs.getFloat("prezzo_r"),
                        rs.getString("partenza"), rs.getString("arrivo"),

                        new Natante(rsNat.getInt("id_natante"), rsNat.getInt("capienzap"),
                                rsNat.getInt("capienzaa"), rsNat.getString("tipo"), rsNat.getString("nome"), comp),null,

                        rs.getInt("postirimasti_p"),rs.getInt("postirimasti_a"),rs.getInt("ritardo"))
                );
                corsa.getLast().setCancellazione(rs.getBoolean("cancellazione"));

            }
        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }

    @Override
    public String cancellaCorsa(int corsaID) {
        try {
            PreparedStatement cancellaCorsa;
            cancellaCorsa = connection.prepareStatement("UPDATE corsa SET cancellazione = true WHERE id_corsa = ?");
            cancellaCorsa.setInt(1, corsaID);
            cancellaCorsa.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }

        return "";
    }

    @Override
    public String modificaRitardo(int corsaID, int ritardo) {
        try {
            PreparedStatement ritardoCorsa;
            ritardoCorsa = connection.prepareStatement("UPDATE corsa SET ritardo = ? WHERE id_corsa = ?");
            ritardoCorsa.setInt(1, ritardo);
            ritardoCorsa.setInt(2, corsaID);
            ritardoCorsa.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }

    @Override
    public String modificaPrezzo(int corsaID, float prezzoI, float prezzoR) {

        try {
            PreparedStatement prezzoCorsa;
            prezzoCorsa = connection.prepareStatement("UPDATE corsa SET prezzo_i = ?,prezzo_r= ? WHERE id_corsa = ?");
            prezzoCorsa.setFloat(1, prezzoI);
            prezzoCorsa.setFloat(2,prezzoR);
            prezzoCorsa.setInt(3, corsaID);
            prezzoCorsa.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }

    @Override
    public String aggiungiNat(Compagnia comp, String nome, String tipo, int capienzaP, int capienzaA) {

        try {
            PreparedStatement inserNat;
            inserNat = connection.prepareStatement(" INSERT INTO natante (compagnia, nome, tipo, capienzap, capienzaa) VALUES (?, ?, ?, ?, ?)");
            inserNat.setString(1, comp.getNome());
            inserNat.setString(2,nome);
            inserNat.setString(3, tipo);
            inserNat.setInt(4,capienzaP);
            inserNat.setInt(5,capienzaA);
            inserNat.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }

    @Override
    public String updateCompDati(String nomeComp, String telefono, String sitoweb, String social, String pass, float sovP, float sovB) {
        try {
            PreparedStatement ControllaCredenziali;
            ControllaCredenziali = connection.prepareStatement("UPDATE compagnia SET telefono=?, sitoweb=?, social=?, passwordcomp=?, sovraprezzo_p=?, sovraprezzo_b=? WHERE nome = ? ");
            ControllaCredenziali.setString(1,telefono);
            ControllaCredenziali.setString(2, sitoweb);
            ControllaCredenziali.setString(3, social);
            ControllaCredenziali.setString(4, pass);
            ControllaCredenziali.setFloat(5,sovP );
            ControllaCredenziali.setFloat(6,sovB );
            ControllaCredenziali.setString(7,nomeComp );
            ControllaCredenziali.executeUpdate();
            return "";
        } catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
    }

    @Override
    public String autoVeicoliComp(Compagnia comp) {
        try {
            PreparedStatement autoVeicoliComp;
            autoVeicoliComp = connection.prepareStatement("SELECT * FROM autoveicolo WHERE nome_compagnia = ?");
            autoVeicoliComp.setString(1, comp.getNome());
            ResultSet rsAT = autoVeicoliComp.executeQuery();

            while (rsAT.next()) {
                comp.getElencoAutoveicoli().add(new Autoveicolo(rsAT.getString("tipo"), rsAT.getFloat("sovraprezzo_a"), rsAT.getInt("dimensione"), comp));
            }

        }catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }

    @Override
    public String updateAV(String autoveicolo,float sovaprezzo,int dimen,Compagnia comp) {
        try {
            PreparedStatement autoVeicoliUpdate;
            autoVeicoliUpdate = connection.prepareStatement("UPDATE autoveicolo SET sovraprezzo_a=?, dimensione=? WHERE nome_compagnia = ? AND tipo= ?");
            autoVeicoliUpdate.setFloat(1, sovaprezzo);
            autoVeicoliUpdate.setInt(2,dimen);
            autoVeicoliUpdate.setString(3,comp.getNome());
            autoVeicoliUpdate.setString(4,autoveicolo);
            autoVeicoliUpdate.executeUpdate();

        }catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }

    @Override
    public String eliminaAutoVeicol(String autoveicolo, String nome) {
        try {
            PreparedStatement autoVeicoliElimina;
            autoVeicoliElimina = connection.prepareStatement("DELETE FROM autoveicolo WHERE nome_compagnia = ? AND tipo= ? ;");
            autoVeicoliElimina.setString(1, nome);
            autoVeicoliElimina.setString(2,autoveicolo);

            autoVeicoliElimina.executeUpdate();

        }catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }

    @Override
    public String addAutoVeicolo(String autoveicolo, float sovaprezzo, int dimen, String nome) {

        try {
            PreparedStatement autoVeicoloAdd;
            autoVeicoloAdd = connection.prepareStatement("INSERT INTO autoveicolo  (tipo, sovraprezzo_a, dimensione, nome_compagnia) VALUES (?, ?, ?, ?)");
            autoVeicoloAdd.setString(1, autoveicolo);
            autoVeicoloAdd.setFloat(2,sovaprezzo);
            autoVeicoloAdd.setInt(3,dimen);
            autoVeicoloAdd.setString(4,nome);

            autoVeicoloAdd.executeUpdate();

        }catch (Exception e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }

    @Override
    public String cercaCadenza(ArrayList<Corsa> corsa, Compagnia comp) {
        PreparedStatement cerca;
        PreparedStatement natante;
        PreparedStatement cadenza;

        try {
                cadenza = connection.prepareStatement("SELECT DISTINCT * FROM cadenza WHERE id_cadenza IN (SELECT id_cadenza FROM corsa WHERE id_natante IN (SELECT id_natante FROM natante WHERE compagnia = ? ))");
                cadenza.setString(1, comp.getNome());
                ResultSet rsCad = cadenza.executeQuery();


            while (rsCad.next()) {
                            cerca = connection.prepareStatement("SELECT * FROM corsa WHERE id_cadenza=? AND cancellazione=false");
                            cerca.setInt(1, rsCad.getInt("id_cadenza"));
                            ResultSet rs = cerca.executeQuery();
                            rs.next();

                            natante = connection.prepareStatement("SELECT * FROM natante WHERE id_natante = ?");
                            natante.setInt(1, rs.getInt("id_natante"));
                            ResultSet rsNat = natante.executeQuery();
                            rsNat.next();

                            corsa.add(new Corsa(rs.getInt("id_corsa"), rs.getDate("data"), rs.getTime("orariop"),
                                    rs.getTime("orarioa"), rs.getFloat("prezzo_i"), rs.getFloat("prezzo_r"),
                                    rs.getString("partenza"), rs.getString("arrivo"),

                                    new Natante(rsNat.getInt("id_natante"), rsNat.getInt("capienzap"),
                                            rsNat.getInt("capienzaa"), rsNat.getString("tipo"), rsNat.getString("nome"), comp),

                                    new Cadenza(rsCad.getInt("id_cadenza"), rsCad.getString("giorno"), rsCad.getDate("periodo_i"), rsCad.getDate("periodo_f")),

                                    rs.getInt("postirimasti_p"), rs.getInt("postirimasti_a"), rs.getInt("ritardo"))
                            );
                        }

        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }

    @Override
    public String elimianCadenza(int idCad) {
        try {
            PreparedStatement cancellaCadezna;
            cancellaCadezna = connection.prepareStatement("DELETE FROM cadenza WHERE id_cadenza=?");
            cancellaCadezna.setInt(1, idCad);
            cancellaCadezna.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }

        return "";
    }

    @Override
    public String modificaCadenza(int idCadenza, String giorni, LocalDate periodoI, LocalDate periodoF, float prezzoI, Float prezzoR) {
        try {
            PreparedStatement modificaCadezna;
            modificaCadezna = connection.prepareStatement("UPDATE cadenza SET giorno=?, periodo_i=?, periodo_f=? WHERE id_cadenza=?");
            modificaCadezna.setString(1,giorni);
            modificaCadezna.setDate(2, Date.valueOf(periodoI));
            modificaCadezna.setDate(3, Date.valueOf(periodoF));
            modificaCadezna.setInt(4, idCadenza);
            modificaCadezna.executeUpdate();

            PreparedStatement modificaCadeznaPrezzo;
            modificaCadeznaPrezzo = connection.prepareStatement("UPDATE corsa SET prezzo_i=?, prezzo_r=? WHERE id_cadenza=?");
            modificaCadeznaPrezzo.setFloat(1,prezzoI);
            modificaCadeznaPrezzo.setFloat(2,prezzoR);
            modificaCadeznaPrezzo.setInt(3, idCadenza);
            modificaCadeznaPrezzo.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            return e.getMessage();
        }
        return "";
    }


}




