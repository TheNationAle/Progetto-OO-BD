package Controller;

import DAO.DAOCli;
import DAO.DAOComp;
import ImplementazioneDAOpostgresql.ImplementazioneDAOClienti;
import ImplementazioneDAOpostgresql.ImplementazioneDAOCompagnia;
import model.*;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;

/**
 * The type Controller.
 */
public class Controller {
    /**
     * Instantiates a new Controller.
     */
    public Controller() {
    }

    /**
     * The Comp.
     */
    public Compagnia comp;//AUTOVEICOLO,Corsa,Natante
    /**
     * The Cli.
     */
    public Cliente cli;//BIGLIETTO
    /**
     * The Cor.
     */
    public ArrayList<Corsa> cor = new ArrayList<>();
    /**
     * The Porti.
     */
    ArrayList<Porto> porti = new ArrayList<>();
    /**
     * The Compagnia.
     */
    DAOComp compagnia = new ImplementazioneDAOCompagnia();
    /**
     * The Cliente.
     */
    DAOCli cliente = new ImplementazioneDAOClienti();

    /**
     * Porti esistenti.
     */
//------------------------------------------------------------Generic
    public void PortiEsistenti() {
        cliente.CercaPortidb(porti);
    }

    /**
     * Controlla credenziali cli boolean.
     *
     * @param Email the email
     * @param Pass  the pass
     * @return the boolean
     */
//------------------------------------------------------------DAO Clienti
    public boolean ControllaCredenzialiCli(String Email, String Pass) {
        cli = new Cliente(Email, Pass);
        cli = cliente.ControlloCredenzialiCli(cli);
        if (cli != null) {
            return true;
        }
        return false;
    }

    /**
     * Crea cliente string.
     *
     * @param nome  the nome
     * @param con   the con
     * @param sex   the sex
     * @param d     the d
     * @param email the email
     * @param pass  the pass
     * @return the string
     */
    public String CreaCliente(String nome, String con, String sex, LocalDate d, String email, String pass) {
        cli = new Cliente(email, pass, nome, con, sex, d);
        return cliente.RegistraCliDb(cli);
    }

    /**
     * Cerca corse string.
     *
     * @param portoP the porto p
     * @param portoA the porto a
     * @param d      the d
     * @param t      the t
     * @param prezzo the prezzo
     * @return the string
     */
    public String CercaCorse(String portoP, String portoA, LocalDate d, LocalTime t, int prezzo) {

        return cliente.cercaCorse(cor, portoP, portoA, d, t, prezzo);
    }

    /**
     * Cerca corse scalo string.
     *
     * @param portoP the porto p
     * @param portoA the porto a
     * @param d      the d
     * @param t      the t
     * @return the string
     */
    public String CercaCorseScalo(String portoP, String portoA, LocalDate d, LocalTime t) {

        return cliente.cercaCorseS(cor, portoP, portoA, d, t);
    }

    /**
     * Add auto veicoli compin corsa.
     *
     * @param i the
     */
    public void addAutoVeicoliCompinCorsa(int i){
        cliente.autoVeicoliCompinCorsa(cor.get(i).getNatante().getNomeCompagnia());
    }

    /**
     * Inserisci biglietto string.
     *
     * @param id          the id
     * @param bag         the bag
     * @param autoveicolo the autoveicolo
     * @param disa        the disa
     * @param preno       the preno
     * @return the string
     */
    public String InserisciBiglietto(int id, int bag, String autoveicolo, boolean disa, boolean preno) {
        return cliente.aggiungiBiglietto(cli, cor.get(id), bag, autoveicolo, disa, preno);
    }

    /**
     * Gets biglietti.
     */
    public void getBiglietti() {
        cliente.getBigliettiPrenotati(cli);
    }

    /**
     * Elimina bigli.
     *
     * @param i the
     */
    public void eliminaBigli(int i) {
        cliente.eliminaBiglietti(cli.getAcquisti().get(i));
    }

    /**
     * Update cli string.
     *
     * @param nome      the nome
     * @param cognome   the cognome
     * @param localDate the local date
     * @param sex       the sex
     * @param pass      the pass
     * @param email     the email
     * @return the string
     */
    public String updateCli(String nome, String cognome, LocalDate localDate, String sex, String pass, String email) {
        String error = cliente.updateCli(nome, cognome, localDate, sex, pass, email);
        cli = cliente.ControlloCredenzialiCli(cli);
        return error;
    }

    //------------------------------------------------------------------Funzioni DAO Comp

    /**
     * In utilizzo nat boolean.
     *
     * @param i the
     * @return the boolean
     */
    public boolean InUtilizzoNat(int i) {
        return compagnia.ControlloCorsaPerNat(comp.getElencoNatanti().get(i));
    }

    /**
     * Controlla credenziali comp boolean.
     *
     * @param Email the email
     * @param Pass  the pass
     * @return the boolean
     */
    public boolean ControllaCredenzialiComp(String Email, String Pass) {
        comp = new Compagnia(Email, Pass);
        comp = compagnia.ControlloCredenzialiComp(comp);
        if (comp != null) {
            return true;
        }
        return false;
    }

    /**
     * Lista nat.
     */
    public void ListaNat() {
        compagnia.SelectNat(comp);
    }

    /**
     * In utilizzo boolean.
     *
     * @param idNatante the id natante
     * @param dataI     the data i
     * @param dataF     the data f
     * @param giorni    the giorni
     * @return the boolean
     */
    public boolean inUtilizzo(int idNatante, LocalDate dataI, LocalDate dataF, String giorni) {
        return compagnia.inUtilizzo(idNatante, dataI, dataF, giorni);
    }

    /**
     * Inserisci corsa string.
     *
     * @param partenza      the partenza
     * @param arrivo        the arrivo
     * @param dataI         the data i
     * @param dataF         the data f
     * @param giorni        the giorni
     * @param orarioP       the orario p
     * @param orarioA       the orario a
     * @param natante       the natante
     * @param prezzoIntero  the prezzo intero
     * @param prezzoRidotto the prezzo ridotto
     * @return the string
     */
    public String inserisciCorsa(String partenza, String arrivo, LocalDate dataI, LocalDate dataF, String giorni, LocalTime orarioP, LocalTime orarioA, int natante, Float prezzoIntero, Float prezzoRidotto) {
        return compagnia.inserisciCorsa(partenza, arrivo, dataI, dataF, giorni, orarioP, orarioA, natante, prezzoIntero, prezzoRidotto);
    }

    /**
     * Elimina natante string.
     *
     * @param natante the natante
     * @return the string
     */
    public String eliminaNatante(int natante) {
        return compagnia.eliminaNatante(natante);
    }

    /**
     * Modifica nome string.
     *
     * @param natante the natante
     * @param nome    the nome
     * @return the string
     */
    public String modificaNome(int natante, String nome) {
        return compagnia.modificaNome(natante, nome);
    }

    /**
     * Cerca corse comp string.
     *
     * @return the string
     */
    public String cercaCorseComp() {
        return compagnia.cercaCorseComp(cor, comp);
    }

    /**
     * Cancella corsa string.
     *
     * @param corsaID the corsa id
     * @return the string
     */
    public String CancellaCorsa(int corsaID) {
        return compagnia.cancellaCorsa(corsaID);
    }

    /**
     * Ritardo corsa string.
     *
     * @param corsaId the corsa id
     * @param ritardo the ritardo
     * @return the string
     */
    public String RitardoCorsa(int corsaId, int ritardo) {
        return compagnia.modificaRitardo(corsaId, ritardo);
    }

    /**
     * Modifica prezzi string.
     *
     * @param corsaID the corsa id
     * @param prezzoI the prezzo i
     * @param prezzoR the prezzo r
     * @return the string
     */
    public String modificaPrezzi(int corsaID, float prezzoI, float prezzoR) {
        return compagnia.modificaPrezzo(corsaID, prezzoI, prezzoR);
    }

    /**
     * Inserisci nat string.
     *
     * @param nome      the nome
     * @param tipo      the tipo
     * @param capienzaP the capienza p
     * @param capienzaA the capienza a
     * @return the string
     */
    public String inserisciNat(String nome, String tipo, int capienzaP, int capienzaA) {
        return compagnia.aggiungiNat(comp, nome, tipo, capienzaP, capienzaA);
    }

    /**
     * Update dati comp string.
     *
     * @param telefono the telefono
     * @param sitoweb  the sitoweb
     * @param social   the social
     * @param pass     the pass
     * @param sovP     the sov p
     * @param sovB     the sov b
     * @return the string
     */
    public String updateDatiComp(String telefono, String sitoweb, String social, String pass, float sovP, float sovB) {
        String error = compagnia.updateCompDati(comp.getNome(), telefono, sitoweb, social, pass, sovP, sovB);
        comp = compagnia.ControlloCredenzialiComp(comp);
        return error;
    }

    /**
     * Auto veicoli comp string.
     *
     * @return the string
     */
    public String autoVeicoliComp() {
        return compagnia.autoVeicoliComp(comp);
    }

    /**
     * Update auto veicolo string.
     *
     * @param autoveicolo the autoveicolo
     * @param sovaprezzo  the sovaprezzo
     * @param dimen       the dimen
     * @return the string
     */
    public String updateAutoVeicolo(String autoveicolo, float sovaprezzo, int dimen) {
        return compagnia.updateAV(autoveicolo, sovaprezzo, dimen, comp);
    }

    /**
     * Elimina autoveicolo string.
     *
     * @param autoveicolo the autoveicolo
     * @return the string
     */
    public String eliminaAutoveicolo(String autoveicolo) {
        return compagnia.eliminaAutoVeicol(autoveicolo, comp.getNome());
    }

    /**
     * Add autoveicolo string.
     *
     * @param autoveicolo the autoveicolo
     * @param sovaprezzo  the sovaprezzo
     * @param dimen       the dimen
     * @return the string
     */
    public String addAutoveicolo(String autoveicolo, float sovaprezzo, int dimen) {
        return compagnia.addAutoVeicolo(autoveicolo, sovaprezzo, dimen, comp.getNome());
    }

    /**
     * Cerca corse cadenza string.
     *
     * @return the string
     */
    public String cercaCorseCadenza() {
        return compagnia.cercaCadenza(cor, comp);
    }

    /**
     * Elimian cadenza string.
     *
     * @param idCad the id cad
     * @return the string
     */
    public String elimianCadenza(int idCad) {
        return compagnia.elimianCadenza(idCad);
    }

    /**
     * Modifica cadenza string.
     *
     * @param idCadenza the id cadenza
     * @param giorni    the giorni
     * @param periodoI  the periodo i
     * @param periodoF  the periodo f
     * @param prezzoI   the prezzo i
     * @param prezzoR   the prezzo r
     * @return the string
     */
    public String modificaCadenza(int idCadenza, String giorni, LocalDate periodoI, LocalDate periodoF, float prezzoI, Float prezzoR) {
        return compagnia.modificaCadenza(idCadenza, giorni, periodoI, periodoF, prezzoI, prezzoR);
    }

    /**
     * Gets email comp.
     *
     * @return the email comp
     */
//-----------------------------------------------------------------Comp
    public String getEmailComp() {
        return comp.getEmail();
    }

    /**
     * Gets pass comp.
     *
     * @return the pass comp
     */
    public String getPassComp() {
        return comp.getPassword();
    }

    /**
     * Gets nome c.
     *
     * @return the nome c
     */
    public String getNomeC() {
        return comp.getNome();
    }

    /**
     * Gets telefono.
     *
     * @return the telefono
     */
    public String getTelefono() {
        return comp.getTelefono();
    }

    /**
     * Gets sito web.
     *
     * @return the sito web
     */
    public String getSitoWeb() {
        return comp.getSitoWeb();
    }

    /**
     * Gets social.
     *
     * @return the social
     */
    public String getSocial() {
        return comp.getSocial();
    }

    /**
     * Gets sovraprezzo b.
     *
     * @return the sovraprezzo b
     */
    public float getSovraprezzo_B() {
        return comp.getSovraprezzo_B();
    }

    /**
     * Gets sovraprezzo p.
     *
     * @return the sovraprezzo p
     */
    public float getSovraprezzo_P() {
        return comp.getSovraprezzo_P();
    }

    /**
     * Gets nome cli.
     *
     * @return the nome cli
     */
//---------------------------------------------------------------Clienti
    public String getNomeCli() {
        return cli.getNome();
    }

    /**
     * Gets email cli.
     *
     * @return the email cli
     */
    public String getEmailCli() {
        return cli.getEmail();
    }

    /**
     * Gets pass cli.
     *
     * @return the pass cli
     */
    public String getPassCli() {
        return cli.getPassword();
    }

    /**
     * Gets congnome.
     *
     * @return the congnome
     */
    public String getCongnome() {
        return cli.getCongnome();
    }

    /**
     * Gets sex.
     *
     * @return the sex
     */
    public String getSex() {
        return cli.getSex();
    }

    /**
     * Gets data n.
     *
     * @return the data n
     */
    public LocalDate getDataN() {
        return cli.getDataN();
    }

    /**
     * Gets acquisti.
     *
     * @return the acquisti
     */
    public ArrayList<Biglietto> getAcquisti() {
        return cli.getAcquisti();
    }


    //------------------------------------------------------------Corse

    /**
     * Svuota arrey cor.
     */
    public void SvuotaArreyCor() {
        cor.clear();
    }

    /**
     * Grande zza arrey cors int.
     *
     * @return the int
     */
    public int GrandeZZAArreyCors() {
        return cor.size();
    }

    /**
     * Gets data.
     *
     * @param i the
     * @return the data
     */
    public Date getData(int i) {
        return cor.get(i).getData();
    }

    /**
     * Gets orario p.
     *
     * @param i the
     * @return the orario p
     */
    public Time getOrario_P(int i) {
        return cor.get(i).getOrario_P();
    }

    /**
     * Gets orario a.
     *
     * @param i the
     * @return the orario a
     */
    public Time getOrario_A(int i) {
        return cor.get(i).getOrario_A();
    }

    /**
     * Gets prezzo i.
     *
     * @param i the
     * @return the prezzo i
     */
    public float getPrezzo_I(int i) {
        return cor.get(i).getPrezzo_I();
    }

    /**
     * Gets prezzo r.
     *
     * @param i the
     * @return the prezzo r
     */
    public float getPrezzo_R(int i) {
        return cor.get(i).getPrezzo_R();
    }

    /**
     * Is cancellazione boolean.
     *
     * @param i the
     * @return the boolean
     */
    public boolean isCancellazione(int i) {
        return cor.get(i).isCancellazione();
    }

    /**
     * Gets ritardo.
     *
     * @param i the
     * @return the ritardo
     */
    public int getRitardo(int i) {
        return cor.get(i).getRitardo();
    }

    /**
     * Gets postirimasti p.
     *
     * @param i the
     * @return the postirimasti p
     */
    public int getPostirimasti_P(int i) {
        return cor.get(i).getPostirimasti_P();
    }

    /**
     * Gets postirimasti a.
     *
     * @param i the
     * @return the postirimasti a
     */
    public int getPostirimasti_A(int i) {
        return cor.get(i).getPostirimasti_A();
    }

    /**
     * Gets natante.
     *
     * @param i the
     * @return the natante
     */
    public Natante getNatante(int i) {
        return cor.get(i).getNatante();
    }

    /**
     * Gets id corsa.
     *
     * @param i the
     * @return the id corsa
     */
    public int getId_corsa(int i) {
        return cor.get(i).getId_corsa();
    }

    /**
     * Gets porto p.
     *
     * @param i the
     * @return the porto p
     */
    public String getPorto_P(int i) {
        return cor.get(i).getPorto_P();
    }

    /**
     * Gets porto a.
     *
     * @param i the
     * @return the porto a
     */
    public String getPorto_A(int i) {
        return cor.get(i).getPorto_A();
    }

    /**
     * Gets tipo nat cliente.
     *
     * @param i the
     * @return the tipo nat cliente
     */
    public String getTipoNatCliente(int i) {
        return cor.get(i).getNatante().getTipo();
    }

    /**
     * Grande zza arrey port int.
     *
     * @return the int
     */
//-------------------------------------------------------------------------------Porti
    public int GrandeZZAArreyPort() {
        return porti.size();
    }

    /**
     * Gets nome porti.
     *
     * @param i the
     * @return the nome porti
     */
    public String getNomePorti(int i) {
        return porti.get(i).getNome();
    }

    /**
     * Svuota arrey nat compag.
     */
//----------------------------------------------------------------------------Natanti in Compagnia
    public void SvuotaArreyNatCompag() {
        comp.getElencoNatanti().clear();
    }

    /**
     * Grande zza arrey nat int.
     *
     * @return the int
     */
    public int GrandeZZAArreyNat() {
        return comp.getElencoNatanti().size();
    }

    /**
     * Gets id natante comp.
     *
     * @param i the
     * @return the id natante comp
     */
    public int getId_NatanteComp(int i) {
        return comp.getElencoNatanti().get(i).getId_Natante();
    }

    /**
     * Gets capienza p comp.
     *
     * @param i the
     * @return the capienza p comp
     */
    public int getCapienzaPComp(int i) {
        return comp.getElencoNatanti().get(i).getCapienzaP();
    }

    /**
     * Gets nome nat comp.
     *
     * @param i the
     * @return the nome nat comp
     */
    public String getNomeNatComp(int i) {
        return comp.getElencoNatanti().get(i).getNome();
    }

    /**
     * Gets nome compagnia comp.
     *
     * @param i the
     * @return the nome compagnia comp
     */
    public String getNomeCompagniaComp(int i) {
        return comp.getElencoNatanti().get(i).getNomeCompagnia().getNome();
    }

    /**
     * Gets capienza a comp.
     *
     * @param i the
     * @return the capienza a comp
     */
    public int getCapienzaAComp(int i) {
        return comp.getElencoNatanti().get(i).getCapienzaA();
    }

    /**
     * Gets tipo nat comp.
     *
     * @param i the
     * @return the tipo nat comp
     */
    public String getTipoNatComp(int i) {
        return comp.getElencoNatanti().get(i).getTipo();
    }


    //------------------------------------------------------------------------Natante in Corsa

    /**
     * Gets id natante corsa.
     *
     * @param i the
     * @return the id natante corsa
     */
    public int getId_NatanteCorsa(int i) {
        return cor.get(i).getNatante().getId_Natante();
    }

    /**
     * Gets nome compagnia corsa.
     *
     * @param i the
     * @return the nome compagnia corsa
     */
    public String getNomeCompagniaCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getNome();
    }

    /**
     * Gets tipo nat corsa.
     *
     * @param i the
     * @return the tipo nat corsa
     */
    public String getTipoNatCorsa(int i) {
        return cor.get(i).getNatante().getTipo();
    }

    //--------------------------------------------------------------------------------Autoveicoli

    /**
     * Svuota arrey auto veicoli.
     */
    public void SvuotaArreyAutoVeicoli() {
        comp.getElencoAutoveicoli().clear();
    }

    /**
     * Grande zza arrey autoveicli int.
     *
     * @return the int
     */
    public int GrandeZZAArreyAutoveicli() {
        return comp.getElencoAutoveicoli().size();
    }

    /**
     * Gets sovraprezzo a.
     *
     * @param i the
     * @return the sovraprezzo a
     */
    public float getSovraprezzo_A(int i) {
        return comp.getElencoAutoveicoli().get(i).getSovraprezzo_A();
    }

    /**
     * Gets dimensione.
     *
     * @param i the
     * @return the dimensione
     */
    public int getDimensione(int i) {
        return comp.getElencoAutoveicoli().get(i).getDimensione();
    }

    /**
     * Gets tipo auto v.
     *
     * @param i the
     * @return the tipo auto v
     */
    public String getTipoAutoV(int i) {
        return comp.getElencoAutoveicoli().get(i).getTipo();
    }

    /**
     * Grande zza arrey autoveicli corsa int.
     *
     * @param i the
     * @return the int
     */
//--------------------------------------------------------------------------------------------Autoveicoli in Corsa
    public int GrandeZZAArreyAutoveicliCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getElencoAutoveicoli().size();
    }

    /**
     * Svuota arrey auto veicoli corsa.
     *
     * @param i the
     */
    public void SvuotaArreyAutoVeicoliCorsa(int i) {
        cor.get(i).getNatante().getNomeCompagnia().getElencoAutoveicoli().clear();
    }

    /**
     * Gets sovraprezzo a corsa.
     *
     * @param i the
     * @param j the j
     * @return the sovraprezzo a corsa
     */
    public float getSovraprezzo_ACorsa(int i, int j) {
                return cor.get(i).getNatante().getNomeCompagnia().getElencoAutoveicoli().get(j).getSovraprezzo_A();
    }

    /**
     * Gets dimensione corsa.
     *
     * @param i the
     * @param j the j
     * @return the dimensione corsa
     */
    public int getDimensioneCorsa(int i, int j) {

        return cor.get(i).getNatante().getNomeCompagnia().getElencoAutoveicoli().get(j).getDimensione();

    }

    /**
     * Gets tipo auto v corsa.
     *
     * @param i   the
     * @param iAV the av
     * @return the tipo auto v corsa
     */
    public String getTipoAutoVCorsa(int i, int iAV) {
       return cor.get(i).getNatante().getNomeCompagnia().getElencoAutoveicoli().get(iAV).getTipo();
        }


    /**
     * Svuota arrey biglietti.
     */
//------------------------------------------------------------Biglietti
    public void SvuotaArreyBiglietti() {
        cli.getAcquisti().clear();
    }

    /**
     * Grande zza arrey biglietti int.
     *
     * @return the int
     */
    public int GrandeZZAArreyBiglietti() {
        return cli.getAcquisti().size();
    }

    /**
     * Gets id biglietto.
     *
     * @param i the
     * @return the id biglietto
     */
    public int getId_Biglietto(int i) {
        return cli.getAcquisti().get(i).getId_Biglietto();
    }

    /**
     * Gets bagagli.
     *
     * @param i the
     * @return the bagagli
     */
    public int getBagagli(int i) {
        return cli.getAcquisti().get(i).getBagagli();
    }

    /**
     * Gets tipo autoveicolo.
     *
     * @param i the
     * @return the tipo autoveicolo
     */
    public String getTipoAutoveicolo(int i) {
        return cli.getAcquisti().get(i).getTipoAutoveicolo();
    }

    /**
     * Is disabilita boolean.
     *
     * @param i the
     * @return the boolean
     */
    public boolean isDisabilita(int i) {
        return cli.getAcquisti().get(i).isDisabilita();
    }

    /**
     * Gets data biglietto.
     *
     * @param i the
     * @return the data biglietto
     */
    public Date getDataBiglietto(int i) {
        return cli.getAcquisti().get(i).getCorsa().getData();
    }

    /**
     * Gets orario p biglietto.
     *
     * @param i the
     * @return the orario p biglietto
     */
    public Time getOrario_PBiglietto(int i) {
        return cli.getAcquisti().get(i).getCorsa().getOrario_P();
    }

    /**
     * Gets orario a biglietto.
     *
     * @param i the
     * @return the orario a biglietto
     */
    public Time getOrario_ABiglietto(int i) {
        return cli.getAcquisti().get(i).getCorsa().getOrario_A();
    }

    /**
     * Gets ritardo biglietto.
     *
     * @param i the
     * @return the ritardo biglietto
     */
    public int getRitardoBiglietto(int i) {
        return cli.getAcquisti().get(i).getCorsa().getRitardo();
    }

    /**
     * Gets natante biglietto.
     *
     * @param i the
     * @return the natante biglietto
     */
    public String getNatanteBiglietto(int i) {
        return cli.getAcquisti().get(i).getCorsa().getNatante().getTipo();
    }

    /**
     * Gets id corsa biglietto.
     *
     * @param i the
     * @return the id corsa biglietto
     */
    public int getId_corsaBiglietto(int i) {
        return cli.getAcquisti().get(i).getCorsa().getId_corsa();
    }

    /**
     * Gets porto p biglietto.
     *
     * @param i the
     * @return the porto p biglietto
     */
    public String getPorto_PBiglietto(int i) {
        return cli.getAcquisti().get(i).getCorsa().getPorto_P();
    }

    /**
     * Gets porto a biglietto.
     *
     * @param i the
     * @return the porto a biglietto
     */
    public String getPorto_ABiglietto(int i) {
        return cli.getAcquisti().get(i).getCorsa().getPorto_A();
    }

    /**
     * Gets giorni.
     *
     * @param i the
     * @return the giorni
     */
//--------------------------------------------------------------------------Cadenza
    public String getGiorni(int i) {
        return cor.get(i).getCadenza().getGiorni();
    }

    /**
     * Gets periodo i.
     *
     * @param i the
     * @return the periodo i
     */
    public Date getPeriodo_I(int i) {
        return cor.get(i).getCadenza().getPeriodo_I();
    }

    /**
     * Gets periodo f.
     *
     * @param i the
     * @return the periodo f
     */
    public Date getPeriodo_F(int i) {
        return cor.get(i).getCadenza().getPeriodo_F();
    }

    /**
     * Gets id cad.
     *
     * @param i the
     * @return the id cad
     */
    public int getId_cad(int i) {
        return cor.get(i).getCadenza().getId_cad();
    }

    /**
     * Gets email comp corsa.
     *
     * @param i the
     * @return the email comp corsa
     */
//-----------------------------------------------------------------CORSAComp
    public String getEmailCompCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getEmail();
    }

    /**
     * Gets pass comp corsa.
     *
     * @param i the
     * @return the pass comp corsa
     */
    public String getPassCompCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getPassword();
    }

    /**
     * Gets nome c corsa.
     *
     * @param i the
     * @return the nome c corsa
     */
    public String getNomeCCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getNome();
    }

    /**
     * Gets telefono corsa.
     *
     * @param i the
     * @return the telefono corsa
     */
    public String getTelefonoCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getTelefono();
    }

    /**
     * Gets sito web corsa.
     *
     * @param i the
     * @return the sito web corsa
     */
    public String getSitoWebCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getSitoWeb();
    }

    /**
     * Gets social corsa.
     *
     * @param i the
     * @return the social corsa
     */
    public String getSocialCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getSocial();
    }

    /**
     * Gets sovraprezzo b corsa.
     *
     * @param i the
     * @return the sovraprezzo b corsa
     */
    public float getSovraprezzo_BCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getSovraprezzo_B();
    }

    /**
     * Gets sovraprezzo p corsa.
     *
     * @param i the
     * @return the sovraprezzo p corsa
     */
    public float getSovraprezzo_PCorsa(int i) {
        return cor.get(i).getNatante().getNomeCompagnia().getSovraprezzo_P();
    }

}
