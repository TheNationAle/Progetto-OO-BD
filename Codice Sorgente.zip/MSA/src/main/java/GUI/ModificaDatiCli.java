package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;


/**
 * The type Modifica dati cli.
 */
public class ModificaDatiCli {

    /**
     * The Frame.
     */
    public JFrame frame;
    private JButton confermaModificaButton;
    private JButton backButton;
    private JTextField textFieldNome;
    private JTextField textFieldCogno;
    private JTextField textFieldEmail;
    private JComboBox comboBoxSex;
    private JTextField textFieldDN;
    private JPasswordField passwordFieldVechia;
    private JPasswordField passwordFieldNuova;
    private JPanel editCliente;

    /**
     * Instantiates a new Modifica dati cli.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public ModificaDatiCli(JFrame frameChiamante, Controller controller) {
            frame = new JFrame("CliInterface");
            frame.setContentPane(editCliente);
            frame.setTitle("MSATasporti");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setSize(1000, 600);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            //impostiamo come dati di default i vecchi dati dell'utente

            textFieldNome.setText(controller.getNomeCli());
            textFieldCogno.setText(controller.getCongnome());
            textFieldEmail.setText(controller.getEmailCli());
            textFieldDN.setText(controller.getDataN().toString());
            passwordFieldNuova.setText("");

            if (controller.cli.getSex().equals("M")) {
                comboBoxSex.addItem("M");
                comboBoxSex.addItem("F");
                comboBoxSex.addItem("Other");

            } else if (controller.getSex().equals("F")) {
                comboBoxSex.addItem("F");
                comboBoxSex.addItem("M");
                comboBoxSex.addItem("Other");

            } else {
                comboBoxSex.addItem("Other");
                comboBoxSex.addItem("M");
                comboBoxSex.addItem("F");
            }

            confermaModificaButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String erorre = null;

                    if (textFieldNome.equals(controller.getNomeCli()) && textFieldCogno.getText().equals(controller.getCongnome())
                            && textFieldDN.getText().equals(controller.getDataN().toString()) && comboBoxSex.getSelectedItem().toString().equals(controller.getSex())) {

                        JOptionPane.showMessageDialog(null,"Nessun Parametro Modificato");
                    }else {
                        try {

                            //prepariamo i dati per l'aggiornamento.

                            String dateInString = textFieldDN.getText();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ITALY);
                            LocalDate dateTime = LocalDate.parse(dateInString, formatter);

                            //controlliamo che la vecchia password inserita sia giusta e che la nuova non sia vuota.

                            if(passwordFieldVechia.getText().equals(controller.getPassCli())&& !passwordFieldNuova.getText().equals("")) {

                                //il metodo updateCli modifica i dati dell'utente

                                erorre = controller.updateCli(textFieldNome.getText(), textFieldCogno.getText(), dateTime, comboBoxSex.getSelectedItem().toString(), passwordFieldNuova.getText(), controller.getEmailCli());
                            }
                            else if(passwordFieldNuova.getText().equals("")){

                                //nel caso in cui non voglia modificare la password chiamiamo il metodo con la password vecchia.

                                erorre = controller.updateCli(textFieldNome.getText(), textFieldCogno.getText(), dateTime, comboBoxSex.getSelectedItem().toString(), controller.getPassCli(), controller.getEmailCli());

                            }
                            if(erorre.equals("")){
                                JOptionPane.showMessageDialog(null,"Modifiche effetuate",null,JOptionPane.OK_OPTION , UIManager.getIcon("OptionPane.questionIcon"));

                            }else {
                                JOptionPane.showMessageDialog(null,erorre);
                            }

                        }catch (Exception dateTime){
                            JOptionPane.showMessageDialog(null,"Data non Acettabile : yyyy-mm-dd");
                        }

                    }

                }
            });

            backButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frameChiamante.setVisible(true);
                    frame.dispose();
                }
            });
        }

}
