package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;

/**

 Nome del Programma: MSA trasporti
 Autori: Alessio Nesi, Marco Guido Scotto Di Uccio, Simone Sommella
 Matricole: N86004465, N86004499, N86004812
 Data Creazione: 3 febbraio 2024
 *
 Descrizione:
 Questo programma è la parte applicativa del progetto OO-BD anno 2023/2024 Traccia 1
 Il programma permette a due tipologie di utenti di accedere al sistema.
 L'utente "Cliente" può visualizzare le corse, acquistare biglietti, visualizzare biglietti,
 modificare i proprio dati e annullare i biglietti acquistati.
 L'utente "Compagnia" può visualizzare le proprie corse attive, i propri natanti,
 gli autoveicoli che possono essere trasportati sui suoi natanti, visualizzre le proprie cadenze
 e può eventualmente modificare, elimionare o aggiungere ognuno di questi parametri oltre a poter modificare i prorpi dati personali.
 *
 Note sulla versione:
 (03/02/2024): Versione finale.

 */

/**
 * The type Home.
 */
public class Home  {

    /**
     * The constant frame.
     */
    public static JFrame frame;
    private JPanel Jpanel1;
    private JLabel scrittaIniziale;
    private JButton buttonComp;
    private JButton buttonClien;

    /**
     * The Controller.
     */
    public Controller controller =  new Controller();

    /**
     * Instantiates a new Home.
     */
    public Home() {

        //Accesso all'applicativo come Compagnia

        buttonComp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            Accesso accesso =new Accesso(frame,"Compagnia",controller);
            accesso.frame.setVisible(true);
            frame.setVisible(false);
            }
        });

        //Accesso all'applicativo come Cliente

        buttonClien.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Accesso accesso =new Accesso(frame,"Clienti",controller);
                accesso.frame.setVisible(true);
                frame.setVisible(false);

            }
        });

    }


    /**
     * Main.
     *
     * @param args the args
     */
    public static void main(String[] args){
        frame = new JFrame("Home");
        frame.setContentPane(new Home().Jpanel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

}
