package org.example;

/**

    Nome del Programma: MSA trasporti
    Autori: Alessio Nesi, Marco Guido Scotto Di Uccio, Simone Sommella
    Matricole: N86004465, N86004499, N86004812
    Data Creazione: 3 febbraio 2024
    *
    Descrizione:
    Questo programma è la parte applicativa del progetto OO-BD anno 2023/2024 Traccia 1
    Il programma permette a due tipologie di utenti di accedere al sistema.
    L'utente "Cliente" può visualizzare le corse, acquistare biglietti, visualizzare biglietti,
    modificare i proprio dati e annullare i biglietti acquistati.
    L'utente "Compagnia" può visualizzare le proprie corse attive, i propri natanti,
    gli autoveicoli che possono essere trasportati sui suoi natanti, visualizzre le proprie cadenze
    e può eventualmente modificare, elimionare o aggiungere ognuno di questi parametri oltre a poter modificare i prorpi dati personali.
    *
    Note sulla versione:
    (03/02/2024): Versione finale.

*/


/**
 * The type Main.
 */
public class Main {
    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {

    }
}