package DAO;

import model.Compagnia;
import model.Corsa;
import model.Natante;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;

/**
 * The interface Dao comp.
 */
public interface DAOComp {
    /**
     * Controllo credenziali comp compagnia.
     *
     * @param Comp the comp
     * @return the compagnia
     */
    Compagnia ControlloCredenzialiComp(Compagnia Comp);

    /**
     * Select nat.
     *
     * @param Comp the comp
     */
    void SelectNat(Compagnia Comp);

    /**
     * Controllo corsa per nat boolean.
     *
     * @param N the n
     * @return the boolean
     */
    boolean ControlloCorsaPerNat(Natante N);

    /**
     * In utilizzo boolean.
     *
     * @param idNatante the id natante
     * @param dataI     the data i
     * @param dataF     the data f
     * @param giorni    the giorni
     * @return the boolean
     */
    boolean inUtilizzo(Integer idNatante, LocalDate dataI, LocalDate dataF, String giorni);

    /**
     * Inserisci corsa string.
     *
     * @param partenza      the partenza
     * @param arrivo        the arrivo
     * @param dataI         the data i
     * @param dataF         the data f
     * @param giorni        the giorni
     * @param orarioP       the orario p
     * @param orarioA       the orario a
     * @param natante       the natante
     * @param prezzoIntero  the prezzo intero
     * @param prezzoRidotto the prezzo ridotto
     * @return the string
     */
    String inserisciCorsa(String partenza, String arrivo, LocalDate dataI, LocalDate dataF, String giorni, LocalTime orarioP, LocalTime orarioA, int natante, Float prezzoIntero, Float prezzoRidotto);

    /**
     * Elimina natante string.
     *
     * @param natante the natante
     * @return the string
     */
    String eliminaNatante(Integer natante);

    /**
     * Modifica nome string.
     *
     * @param natante the natante
     * @param nome    the nome
     * @return the string
     */
    String modificaNome(Integer natante, String nome);

    /**
     * Cerca corse comp string.
     *
     * @param corsa the corsa
     * @param comp  the comp
     * @return the string
     */
    String cercaCorseComp(ArrayList<Corsa> corsa, Compagnia comp);

    /**
     * Cancella corsa string.
     *
     * @param corsaID the corsa id
     * @return the string
     */
    String cancellaCorsa(int corsaID);

    /**
     * Modifica ritardo string.
     *
     * @param corsaID the corsa id
     * @param ritardo the ritardo
     * @return the string
     */
    String modificaRitardo(int corsaID,int ritardo);

    /**
     * Modifica prezzo string.
     *
     * @param corsaID the corsa id
     * @param prezzoI the prezzo i
     * @param prezzoR the prezzo r
     * @return the string
     */
    String modificaPrezzo(int corsaID,float prezzoI,float prezzoR);

    /**
     * Aggiungi nat string.
     *
     * @param comp      the comp
     * @param nome      the nome
     * @param tipo      the tipo
     * @param capienzaP the capienza p
     * @param capienzaA the capienza a
     * @return the string
     */
    String aggiungiNat(Compagnia comp, String nome, String tipo, int capienzaP, int capienzaA);

    /**
     * Update comp dati string.
     *
     * @param nomeComp the nome comp
     * @param telefono the telefono
     * @param sitoweb  the sitoweb
     * @param social   the social
     * @param pass     the pass
     * @param sovP     the sov p
     * @param sovB     the sov b
     * @return the string
     */
    String updateCompDati(String nomeComp, String telefono, String sitoweb, String social, String pass, float sovP, float sovB);

    /**
     * Auto veicoli comp string.
     *
     * @param comp the comp
     * @return the string
     */
    String autoVeicoliComp(Compagnia comp);

    /**
     * Update av string.
     *
     * @param autoveicolo the autoveicolo
     * @param sovaprezzo  the sovaprezzo
     * @param dimen       the dimen
     * @param comp        the comp
     * @return the string
     */
    String updateAV(String autoveicolo,float sovaprezzo,int dimen,Compagnia comp);

    /**
     * Elimina auto veicol string.
     *
     * @param autoveicolo the autoveicolo
     * @param nome        the nome
     * @return the string
     */
    String eliminaAutoVeicol(String autoveicolo,String nome);

    /**
     * Add auto veicolo string.
     *
     * @param autoveicolo the autoveicolo
     * @param sovaprezzo  the sovaprezzo
     * @param dimen       the dimen
     * @param nome        the nome
     * @return the string
     */
    String addAutoVeicolo(String autoveicolo,float sovaprezzo,int dimen,String nome);

    /**
     * Cerca cadenza string.
     *
     * @param corsa the corsa
     * @param comp  the comp
     * @return the string
     */
    String cercaCadenza(ArrayList<Corsa> corsa, Compagnia comp);

    /**
     * Elimian cadenza string.
     *
     * @param idCad the id cad
     * @return the string
     */
    String elimianCadenza(int idCad);

    /**
     * Modifica cadenza string.
     *
     * @param idCadenza the id cadenza
     * @param giorni    the giorni
     * @param periodoI  the periodo i
     * @param periodoF  the periodo f
     * @param prezzoI   the prezzo i
     * @param prezzoR   the prezzo r
     * @return the string
     */
    String modificaCadenza(int idCadenza, String giorni, LocalDate periodoI, LocalDate periodoF, float prezzoI, Float prezzoR);

}



