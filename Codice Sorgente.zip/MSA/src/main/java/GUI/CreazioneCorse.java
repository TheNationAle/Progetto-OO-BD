package GUI;

import Controller.Controller;
import model.Compagnia;
import model.Porto;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

/**
 * The type Creazione corse.
 */
public class CreazioneCorse {
    /**
     * The Frame.
     */
    public JFrame frame;
    private JPanel panelCreazioneCors;
    private JComboBox partenzaComboBox;
    private JComboBox arrivoComboBox;
    private JCheckBox lunediCheckBox;
    private JCheckBox martediCheckBox;
    private JCheckBox mercolediCheckBox;
    private JCheckBox giovediCheckBox;
    private JCheckBox venerdiCheckBox;
    private JCheckBox sabatoCheckBox;
    private JCheckBox domenicaCheckBox;
    private JSpinner orePartenzaSpinner;
    private JSpinner minutiPartenzaSpinner;
    private JSpinner oreArrivoSpinner;
    private JSpinner minutiArrivoSpinner;
    private JComboBox natanteComboBox;
    private JTextField prezzoInteroTextField;
    private JTextField prezzoRidottoTextField;
    private JButton backButton;
    private JButton creaCorsaButton;
    private JPanel panelGiorni;
    private JPanel panelPeriodo;
    private JTextField periodoITextField;
    private JTextField periodoFTextField;
    private Float prezzoIntero;
    private Float prezzoRidotto;

    /**
     * Instantiates a new Creazione corse.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public CreazioneCorse(JFrame frameChiamante, Controller controller) {

        frame = new JFrame("CompInterface");
        frame.setContentPane(panelCreazioneCors);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                natanteComboBox.removeAllItems();
                controller.SvuotaArreyNatCompag();
                frameChiamante.setVisible(true);
                frame.dispose();
            }
        });

        /** inizializziamo le combobox con i porti esistenti */

        controller.PortiEsistenti();
        for(int i = 0; i <controller.GrandeZZAArreyPort(); i++){
            partenzaComboBox.addItem(controller.getNomePorti(i));
            arrivoComboBox.addItem(controller.getNomePorti(i));
        }
        arrivoComboBox.setSelectedItem(partenzaComboBox.getItemAt(arrivoComboBox.getItemCount()-1));

        periodoITextField.setText(String.valueOf(LocalDate.now()));
        periodoFTextField.setText(String.valueOf(LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonthValue(), LocalDate.now().getDayOfMonth()+1)));

        /** limitiamo gli spinner e impediamone la modifica tramite input da tastiera */

        SpinnerNumberModel numberModelOraP = new SpinnerNumberModel();
        numberModelOraP.setMaximum(23);
        numberModelOraP.setMinimum(0);

        SpinnerNumberModel numberModelOraA = new SpinnerNumberModel();
        numberModelOraA.setMaximum(23);
        numberModelOraA.setMinimum(0);

        oreArrivoSpinner.setModel(numberModelOraA);
        orePartenzaSpinner.setModel(numberModelOraP);

        orePartenzaSpinner.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                e.consume();
            }
        });

        oreArrivoSpinner.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                e.consume();
            }
        });

        SpinnerNumberModel numberModelMinP = new SpinnerNumberModel();
        numberModelMinP.setMaximum(59);
        numberModelMinP.setMinimum(0);

        SpinnerNumberModel numberModelMinA = new SpinnerNumberModel();
        numberModelMinA.setMaximum(59);
        numberModelMinA.setMinimum(0);

        minutiArrivoSpinner.setModel(numberModelMinA);
        minutiPartenzaSpinner.setModel(numberModelMinP);

        minutiArrivoSpinner.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                e.consume();
            }
        });

        minutiPartenzaSpinner.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                e.consume();
            }
        });

        for (int i = 0; i < controller.GrandeZZAArreyNat(); i++) {
            natanteComboBox.addItem(controller.getId_NatanteComp(i) + " - " + controller.getNomeNatComp(i));
        }

        creaCorsaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                /** controlliamo che il porto di partenza sia diverso da quello di arrivo */

                if (partenzaComboBox.getSelectedItem().toString().equals(arrivoComboBox.getSelectedItem().toString())) {
                    JOptionPane.showMessageDialog(null, "Selezionare porti distinti");
                } else {

                    LocalDate dataI = null;
                    LocalDate dataF = null;

                    /** prepariamo le variabili rendendole del tipo giusto per l'inserimento */

                    try {
                        prezzoRidotto = Float.valueOf(prezzoInteroTextField.getText());
                        prezzoIntero = prezzoRidotto;
                        if (prezzoIntero < 0) throw new Exception();
                        prezzoRidotto = Float.valueOf(prezzoRidottoTextField.getText());
                        if (prezzoRidotto < 0) throw new Exception();
                    } catch (Exception exception) {
                        prezzoRidotto = null;
                        prezzoIntero = null;
                        JOptionPane.showMessageDialog(null, "Prezzo non valido");
                    }

                    try {

                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ITALIAN);
                        dataI = LocalDate.parse(periodoITextField.getText(), formatter);
                        dataF = LocalDate.parse(periodoFTextField.getText(), formatter);

                    } catch (DateTimeException dateTimeException) {
                        JOptionPane.showMessageDialog(null, "Inserire un periodo valido (YYYY-MM-dd)");
                    }

                    if ((dataI.isAfter(LocalDate.now()) || dataI.isEqual(LocalDate.now())) && dataF.isAfter(dataI)) {

                        if (lunediCheckBox.isSelected() || martediCheckBox.isSelected() ||
                                mercolediCheckBox.isSelected() || giovediCheckBox.isSelected() ||
                                venerdiCheckBox.isSelected() || sabatoCheckBox.isSelected() ||
                                domenicaCheckBox.isSelected()) {

                            String temp;
                            String giorni = "";
                            LocalTime orarioA;
                            LocalTime orarioP;
                            DateTimeFormatter formatTempP = DateTimeFormatter.ofPattern("HH:mm", Locale.ITALY);

                            /**Codice di controllo di inserimento orario con eventuale correzioni di inserimento da parte della comapgnia  */

                            if (10 > (int) oreArrivoSpinner.getValue() && 10 > (int) minutiArrivoSpinner.getValue()) {
                                temp = "0" + oreArrivoSpinner.getValue().toString() + ":0" + minutiArrivoSpinner.getValue().toString();

                            } else if (10 > (int) minutiArrivoSpinner.getValue()) {
                                temp = oreArrivoSpinner.getValue().toString() + ":0" + minutiArrivoSpinner.getValue().toString();

                            } else if (10 > (int) oreArrivoSpinner.getValue()) {
                                temp = "0" + oreArrivoSpinner.getValue().toString() + ":" + minutiArrivoSpinner.getValue().toString();

                            } else {
                                temp = oreArrivoSpinner.getValue().toString() + ":" + minutiArrivoSpinner.getValue().toString();
                            }

                            orarioA = LocalTime.parse(temp, formatTempP);

                            if (10 > (int) orePartenzaSpinner.getValue() && 10 > (int) minutiPartenzaSpinner.getValue()) {
                                temp = "0" + orePartenzaSpinner.getValue().toString() + ":0" + minutiPartenzaSpinner.getValue().toString();

                            } else if (10 > (int) minutiPartenzaSpinner.getValue()) {
                                temp = orePartenzaSpinner.getValue().toString() + ":0" + minutiPartenzaSpinner.getValue().toString();

                            } else if (10 > (int) orePartenzaSpinner.getValue()) {
                                temp = "0" + orePartenzaSpinner.getValue().toString() + ":" + minutiPartenzaSpinner.getValue().toString();

                            } else {
                                temp = orePartenzaSpinner.getValue().toString() + ":" + minutiPartenzaSpinner.getValue().toString();
                            }

                            orarioP = LocalTime.parse(temp, formatTempP);

                            if (orarioA.isAfter(orarioP)) {

                                if (lunediCheckBox.isSelected()) giorni = giorni + "Monday, ";
                                if (martediCheckBox.isSelected()) giorni = giorni + "Tuesday, ";
                                if (mercolediCheckBox.isSelected()) giorni = giorni + "Wednesday, ";
                                if (giovediCheckBox.isSelected()) giorni = giorni + "Thursday, ";
                                if (venerdiCheckBox.isSelected()) giorni = giorni + "Friday, ";
                                if (sabatoCheckBox.isSelected()) giorni = giorni + "Saturday, ";
                                if (domenicaCheckBox.isSelected()) giorni = giorni + "Sunday, ";

                                giorni = giorni.substring(0, giorni.length() - 2);

                                /** il metodo inUtilizzo controlla che il natante selezionato non sia già occupato in altre corse
                                 *  durante i giorni selezionati dalla compagnia per creare nuove corse */

                                if (!controller.inUtilizzo(Integer.valueOf(natanteComboBox.getSelectedItem().toString().substring(0, natanteComboBox.getSelectedItem().toString().indexOf(" "))), dataI, dataF, giorni)) {
                                    if (prezzoIntero != null && prezzoRidotto != null) {

                                        /** il metodo inserisciCorsa inserisce all'interno del database una nuova cadenza e crea
                                         *  tutte le corse di quella cadenza */

                                        String messaggio = controller.inserisciCorsa(partenzaComboBox.getSelectedItem().toString(), arrivoComboBox.getSelectedItem().toString(),
                                                dataI, dataF, giorni, orarioP, orarioA, Integer.valueOf(natanteComboBox.getSelectedItem().toString().substring(0, natanteComboBox.getSelectedItem().toString().indexOf(" "))), prezzoIntero, prezzoRidotto);
                                        JOptionPane.showMessageDialog(null, messaggio);
                                        if (messaggio.equals("Corse create")) {
                                            natanteComboBox.removeAllItems();
                                            controller.SvuotaArreyNatCompag();
                                            frameChiamante.setVisible(true);
                                            frame.dispose();
                                        }

                                    }
                                } else {
                                    JOptionPane.showMessageDialog(null, "Natante già in attività durante questi giorni, selezionare un altro natante o cambiare periodo");
                                }

                            } else {
                                JOptionPane.showMessageDialog(null, "Orario di arrivo non valido");
                            }

                        } else {
                            JOptionPane.showMessageDialog(null, "Selezionare almeno un giorno della settimana");
                        }

                    } else {
                        JOptionPane.showMessageDialog(null, "Inserire periodo valido");
                    }

                }
            }
        });

    }


}


