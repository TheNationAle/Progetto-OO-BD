package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

/**
 * The type Cliente.
 */
public class Cliente extends Utente {
    private String nome;
    private String congnome;
    private String sex;
    private LocalDate dataN;

    private ArrayList<Biglietto>acquisti= new ArrayList<Biglietto>();

    /**
     * Instantiates a new Cliente.
     *
     * @param email    the email
     * @param password the password
     * @param nome     the nome
     * @param congnome the congnome
     * @param sex      the sex
     * @param dataN    the data n
     */
    public Cliente(String email, String password, String nome, String congnome, String sex, LocalDate dataN) {
        super(email, password);
        this.nome = nome;
        this.congnome = congnome;
        this.sex = sex;
        this.dataN = dataN;
    }

    /**
     * Instantiates a new Cliente.
     *
     * @param email    the email
     * @param password the password
     */
    public Cliente(String email,String password){
        super(email,password);
    }

    /**
     * Gets nome.
     *
     * @return the nome
     */
    public String getNome() {
            return nome;
    }

    /**
     * Sets nome.
     *
     * @param nome the nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Gets congnome.
     *
     * @return the congnome
     */
    public String getCongnome() {
        return congnome;
    }

    /**
     * Sets congnome.
     *
     * @param congnome the congnome
     */
    public void setCongnome(String congnome) {
        this.congnome = congnome;
    }

    /**
     * Gets sex.
     *
     * @return the sex
     */
    public String getSex() {
        return sex;
    }

    /**
     * Sets sex.
     *
     * @param sex the sex
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * Gets data n.
     *
     * @return the data n
     */
    public LocalDate getDataN() {
        return dataN;
    }

    /**
     * Sets data n.
     *
     * @param dataN the data n
     */
    public void setDataN(LocalDate dataN) {
        this.dataN = dataN;
    }

    /**
     * Gets acquisti.
     *
     * @return the acquisti
     */
    public ArrayList<Biglietto> getAcquisti() {
        return acquisti;
    }

    /**
     * Sets acquisti.
     *
     * @param acquisti the acquisti
     */
    public void setAcquisti(ArrayList<Biglietto> acquisti) {
        this.acquisti = acquisti;
    }

    /**
     * Cancella biglietti.
     *
     * @param b the b
     */
    void CancellaBiglietti(Biglietto b){
        acquisti.remove(b);
    }
}
