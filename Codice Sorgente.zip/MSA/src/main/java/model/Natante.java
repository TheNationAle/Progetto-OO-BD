package model;

import java.util.ArrayList;

/**
 * The type Natante.
 */
public class Natante {
    private int id_Natante;
    private int capienzaP;
    private int capienzaA;
    private String tipo;
    private String nome;
    private Compagnia nomeCompagnia;
    private ArrayList<Corsa> effetua =new ArrayList<Corsa>();


    /**
     * Instantiates a new Natante.
     *
     * @param id_Natante    the id natante
     * @param capienzaP     the capienza p
     * @param capienzaA     the capienza a
     * @param tipo          the tipo
     * @param nome          the nome
     * @param nomeCompagnia the nome compagnia
     */
    public Natante(int id_Natante, int capienzaP, int capienzaA, String tipo, String nome, Compagnia nomeCompagnia) {
        this.id_Natante = id_Natante;
        this.capienzaP = capienzaP;
        this.capienzaA = capienzaA;
        this.tipo = tipo;
        this.nome = nome;
        this.nomeCompagnia = nomeCompagnia;
    }

    /**
     * Instantiates a new Natante.
     *
     * @param capienzaP     the capienza p
     * @param capienzaA     the capienza a
     * @param tipo          the tipo
     * @param nome          the nome
     * @param nomeCompagnia the nome compagnia
     */
    public Natante( int capienzaP, int capienzaA, String tipo, String nome, Compagnia nomeCompagnia) {
        this.capienzaP = capienzaP;
        this.capienzaA = capienzaA;
        this.tipo = tipo;
        this.nome = nome;
        this.nomeCompagnia = nomeCompagnia;
    }

    /**
     * Gets id natante.
     *
     * @return the id natante
     */
    public int getId_Natante() {
        return id_Natante;
    }

    /**
     * Sets id natante.
     *
     * @param id_Natante the id natante
     */
    public void setId_Natante(int id_Natante) {
        this.id_Natante = id_Natante;
    }

    /**
     * Gets capienza p.
     *
     * @return the capienza p
     */
    public int getCapienzaP() {
        return capienzaP;
    }

    /**
     * Sets capienza p.
     *
     * @param capienzaP the capienza p
     */
    public void setCapienzaP(int capienzaP) {
        this.capienzaP = capienzaP;
    }


    /**
     * Gets nome.
     *
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Sets nome.
     *
     * @param nome the nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Gets nome compagnia.
     *
     * @return the nome compagnia
     */
    public Compagnia getNomeCompagnia() {
        return nomeCompagnia;
    }

    /**
     * Sets nome compagnia.
     *
     * @param nomeCompagnia the nome compagnia
     */
    public void setNomeCompagnia(Compagnia nomeCompagnia) {
        this.nomeCompagnia = nomeCompagnia;
    }

    /**
     * Gets effetua.
     *
     * @return the effetua
     */
    public ArrayList<Corsa> getEffetua() {
        return effetua;
    }

    /**
     * Sets effetua.
     *
     * @param effetua the effetua
     */
    public void setEffetua(ArrayList<Corsa> effetua) {
        this.effetua = effetua;
    }

    /**
     * Gets capienza a.
     *
     * @return the capienza a
     */
    public int getCapienzaA() {
        return capienzaA;
    }

    /**
     * Sets capienza a.
     *
     * @param capienzaA the capienza a
     */
    public void setCapienzaA(int capienzaA) {
        this.capienzaA = capienzaA;
    }

    /**
     * Gets tipo.
     *
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Sets tipo.
     *
     * @param tipo the tipo
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}


