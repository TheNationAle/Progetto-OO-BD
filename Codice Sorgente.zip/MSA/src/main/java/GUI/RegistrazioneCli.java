package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * The type Registrazione cli.
 */
public class RegistrazioneCli {

    /**
     * The Frame.
     */
    public JFrame frame ;
    private JPanel registrazioneUt;
    private JLabel datadiNascita;
    private JTextField cognome;
    private JTextField nome;
    private JPasswordField passwordField1;
    private JPasswordField passwordCField2;
    private JTextField email;
    private JButton backButton;
    private JButton registratiButton;
    private JComboBox comboBoxSex;
    private JTextField datan;

    /**
     * Instantiates a new Registrazione cli.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public RegistrazioneCli(JFrame frameChiamante ,Controller controller) {

        frame=new JFrame("Acesso");
        frame.setContentPane(registrazioneUt);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        //inizializziamo la comboBox con i dati che può inserire l'utente.

        comboBoxSex.addItem("M");
        comboBoxSex.addItem("F");
        comboBoxSex.addItem("Other");

        registratiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                //controlliamo che non ci siano campi vuoti al momento della registrazione.

                if (!nome.getText().equals("") && !cognome.getText().equals("") && !comboBoxSex.getSelectedItem().toString().equals("") && !email.getText().equals("") && !passwordField1.getText().equals("")){

                    //controlliamo che la password inserita sia uguale al conferma password

                    if(passwordField1.getText().equals(passwordCField2.getText())){
                        try {

                            //rendiamo i dati del tipo giusto per l'inserimento.

                            String dateInString = datan.getText();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ITALY);
                            LocalDate dateTime = LocalDate.parse(dateInString, formatter);

                            //la procedura CreaCliente inserisce all'interno del database il nuovo cliente con i dati inseriti in precedenza

                            String error=controller.CreaCliente(nome.getText(),cognome.getText(),comboBoxSex.getSelectedItem().toString(),dateTime,email.getText(),passwordCField2.getText());
                            if(!error.equals("")){
                                JOptionPane.showMessageDialog(null,error);

                            }else {
                                JOptionPane.showMessageDialog(null,"Account Creato");
                                frameChiamante.setVisible(true);
                                frame.dispose();
                            }
                        }catch (Exception dateTime){
                            JOptionPane.showMessageDialog(null,"Data non Acettabile : yyyy-mm-dd",null,JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                        }

                    }else {
                        JOptionPane.showMessageDialog(null,"Password non combaciante",null,JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                    }
                }else{
                    JOptionPane.showMessageDialog(null,"Inserisi tutti i valori",null,JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                }


            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameChiamante.setVisible(true);
                frame.dispose();
            }
        });



    }
}
