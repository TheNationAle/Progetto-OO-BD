package GUI;

import Controller.Controller;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The type Modifica cadenza corse.
 */
public class modificaCadenzaCorse {

    /**
     * The Frame.
     */
    public JFrame frame;
    private JTable tableCorse;
    private JButton backButton;
    private JButton elliminaButton;
    private JButton modificaButton;
    private JPanel modificaCad;
    private JComboBox comboBoxCorsa;

    /**
     * Instantiates a new Modifica cadenza corse.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public modificaCadenzaCorse(JFrame frameChiamante , Controller controller){

        frame = new JFrame("CompInterface");
        frame.setContentPane(modificaCad);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        controller.cercaCorseCadenza();
        tableCorse.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        DefaultTableModel tabelModel = new DefaultTableModel(new Object[][]{}, new String[]{"ID Cadenza", "Porto Partenza", "Porto Arrivo", "Giorni","Periodo Inizio","Periodo Di Fine", "Prezzo Intero","Prezzo ridotto"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableCorse.setEnabled(true);
        tableCorse.setModel(tabelModel);
        tableCorse.getTableHeader().setReorderingAllowed(false);

        /** riempiamo la tabella con una corsa generica per ogni cadenza della compagnia */

        for (int i = tabelModel.getRowCount(); i <controller.GrandeZZAArreyCors(); i++) {

                tabelModel.addRow(new Object[]{controller.getId_cad(i), controller.getPorto_P(i), controller.getPorto_A(i), controller.getGiorni(i),
                        controller.getPeriodo_I(i), controller.getPeriodo_F(i), controller.getPrezzo_I(i),controller.getPrezzo_R(i)});

            comboBoxCorsa.addItem(controller.getId_cad(i));
        }

        elliminaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] opzioni = {"Si", "No"};
                int option = JOptionPane.showOptionDialog(null, "Sei sicuro di voler eliminare questa cadenza" +
                        "\ne cancellare tutte le Corse a qui appartiene ?", "Warning", 0, 2, UIManager.getIcon("OptionPane.warningIcon"), opzioni, opzioni[0]);
                if (option == 0) {

                    /** il metodo eliminaCadenza elimina dalla base dati
                     * la cadenza selezionata e tutte le corse annesse */

                    String erorr=controller.elimianCadenza(Integer.valueOf(comboBoxCorsa.getSelectedItem().toString()));
                    if(!erorr.equals("")){
                        JOptionPane.showMessageDialog(null,erorr,"Erorr",JOptionPane.OK_OPTION,UIManager.getIcon("OptionPane.errorIcon"));
                    }else {
                        JOptionPane.showMessageDialog(null,"Corsa :"+comboBoxCorsa.getSelectedItem()+" cancellata");
                        controller.SvuotaArreyCor();
                        frameChiamante.setVisible(true);
                        frame.dispose();
                    }
                }
            }
        });

        modificaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ModificaCadenza modCad= new ModificaCadenza(frameChiamante,frame,controller,Integer.valueOf(comboBoxCorsa.getSelectedItem().toString()));
                modCad.frame.setVisible(true);
                frame.dispose();

            }
        });


        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.SvuotaArreyCor();
                frameChiamante.setVisible(true);
                frame.dispose();
            }
        });
    }
}
