package GUI;

import Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * The type Modifica dati comp.
 */
public class ModificaDatiComp {

    /**
     * The Frame.
     */
    public JFrame frame;
    private JButton confermaModificeButton;
    private JButton backButton;
    private JTextField textFieldSocial;
    private JTextField textFieldTelefono;
    private JTextField textFieldSitoWeb;
    private JTextField textFieldPV;
    private JSpinner spinnerEuroP;
    private JSpinner spinnerCentesimiP;
    private JSpinner spinnerEuroB;
    private JSpinner spinnerCentesimiB;
    private JPasswordField textFieldPN;
    private JLabel NomeComp;
    private JLabel emailComp;
    private JPanel modificaDatiComp;

    /**
     * Instantiates a new Modifica dati comp.
     *
     * @param frameChiamante the frame chiamante
     * @param controller     the controller
     */
    public ModificaDatiComp(JFrame frameChiamante , Controller controller){

        frame = new JFrame("CompInterface");
        frame.setContentPane(modificaDatiComp);
        frame.setTitle("MSATasporti");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(1000,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        /** Inseriamo come dati di partenza gli attuali dati della compagnia */

        NomeComp.setText(controller.getNomeC());
        emailComp.setText(controller.getEmailComp());

        textFieldTelefono.setText(controller.getTelefono());
        textFieldSitoWeb.setText(controller.getSitoWeb());
        textFieldSocial.setText(controller.getSocial());

        /** limitiamo gli spinner */

        SpinnerNumberModel numberEuroP = new SpinnerNumberModel();
        numberEuroP.setMaximum(999);
        numberEuroP.setMinimum(0);

        SpinnerNumberModel numberCentP= new SpinnerNumberModel();
        numberCentP.setMaximum(99);
        numberCentP.setMinimum(0);

        SpinnerNumberModel numberEuroB = new SpinnerNumberModel();
        numberEuroB.setMaximum(999);
        numberEuroB.setMinimum(0);

        SpinnerNumberModel numberCentB= new SpinnerNumberModel();
        numberCentB.setMaximum(99);
        numberCentB.setMinimum(0);

        spinnerEuroP.setModel(numberEuroP);
        spinnerEuroP.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                e.consume();
            }
        });

        spinnerCentesimiP.setModel(numberCentP);
        spinnerCentesimiP.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                e.consume();
            }
        });

        spinnerEuroB.setModel(numberEuroB);
        spinnerEuroB.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                e.consume();
            }
        });

        spinnerCentesimiB.setModel(numberCentB);
        spinnerCentesimiB.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyPressed(KeyEvent e) {
                e.consume();
            }

            @Override
            public void keyReleased(KeyEvent e) {
                e.consume();
            }
        });

        spinnerEuroP.setValue((int)controller.getSovraprezzo_P());
        spinnerCentesimiP.setValue((int) ((controller.getSovraprezzo_P() % 1) * 100));

        spinnerEuroB.setValue((int)controller.getSovraprezzo_B());
        spinnerCentesimiB.setValue((int) ((controller.getSovraprezzo_B() % 1) * 100));


        confermaModificeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String erorre;

                /** prima di attuare le modifiche controlliamo
                 *  che la password vecchia sia corretta */

                if(textFieldPV.getText().equals(controller.getPassComp())){
                    if(!textFieldPN.getText().equals("")){
                       erorre= controller.updateDatiComp(textFieldTelefono.getText(),textFieldSitoWeb.getText(),textFieldSocial.getText(),textFieldPN.getText(),
                                Float.valueOf(spinnerEuroP.getValue().toString()+"."+spinnerCentesimiP.getValue().toString()),Float.valueOf(spinnerEuroB.getValue().toString()+"."+spinnerCentesimiB.getValue().toString()));
                    }else {
                         erorre=controller.updateDatiComp(textFieldTelefono.getText(),textFieldSitoWeb.getText(),textFieldSocial.getText(),textFieldPV.getText(),
                                Float.valueOf(spinnerEuroP.getValue().toString()+"."+spinnerCentesimiP.getValue().toString()),Float.valueOf(spinnerEuroB.getValue().toString()+"."+spinnerCentesimiB.getValue().toString()));
                    }
                    if (erorre.equals("")){
                        JOptionPane.showMessageDialog(null,"Modifiche Effetuate");


                    }else
                    {
                        JOptionPane.showMessageDialog(null,erorre);
                    }

                }else{
                    JOptionPane.showMessageDialog(null,"Inserire la Password coretta per la modifica dei Dati ");
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameChiamante.setVisible(true);
                frame.dispose();
            }
        });
    }
}
