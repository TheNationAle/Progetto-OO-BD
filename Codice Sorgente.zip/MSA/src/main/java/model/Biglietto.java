package model;

/**
 * The type Biglietto.
 */
public class Biglietto {

    private int id_Biglietto;
    private boolean prenotazione;
    private int bagagli;
    private String tipoAutoveicolo;
    private boolean disabilita;
    private Corsa corsa;
    private Cliente cliente;

    /**
     * Instantiates a new Biglietto.
     *
     * @param id_Biglietto    the id biglietto
     * @param prenotazione    the prenotazione
     * @param bagagli         the bagagli
     * @param tipoAutoveicolo the tipo autoveicolo
     * @param disabilita      the disabilita
     * @param corsa           the corsa
     * @param cliente         the cliente
     */
    public Biglietto(int id_Biglietto, boolean prenotazione, int bagagli, String tipoAutoveicolo,
                                       boolean disabilita, Corsa corsa, Cliente cliente) {
        this.id_Biglietto = id_Biglietto;
        this.prenotazione = prenotazione;
        this.bagagli = bagagli;
        this.tipoAutoveicolo = tipoAutoveicolo;
        this.disabilita = disabilita;
        this.corsa = corsa;
        this.cliente = cliente;
    }

    /**
     * Instantiates a new Biglietto.
     *
     * @param prenotazione    the prenotazione
     * @param bagagli         the bagagli
     * @param tipoAutoveicolo the tipo autoveicolo
     * @param disabilita      the disabilita
     * @param corsa           the corsa
     * @param cliente         the cliente
     */
    public Biglietto(boolean prenotazione, int bagagli, String tipoAutoveicolo,
                     boolean disabilita, Corsa corsa, Cliente cliente) {
        this.prenotazione = prenotazione;
        this.bagagli = bagagli;
        this.tipoAutoveicolo = tipoAutoveicolo;
        this.disabilita = disabilita;
        this.corsa = corsa;
        this.cliente = cliente;
    }

    /**
     * Gets id biglietto.
     *
     * @return the id biglietto
     */
    public int getId_Biglietto() {
        return id_Biglietto;
    }

    /**
     * Sets id biglietto.
     *
     * @param id_Biglietto the id biglietto
     */
    public void setId_Biglietto(int id_Biglietto) {
        this.id_Biglietto = id_Biglietto;
    }

    /**
     * Is prenotazione boolean.
     *
     * @return the boolean
     */
    public boolean isPrenotazione() {
        return prenotazione;
    }

    /**
     * Sets prenotazione.
     *
     * @param prenotazione the prenotazione
     */
    public void setPrenotazione(boolean prenotazione) {
        this.prenotazione = prenotazione;
    }

    /**
     * Gets bagagli.
     *
     * @return the bagagli
     */
    public int getBagagli() {
        return bagagli;
    }

    /**
     * Sets bagagli.
     *
     * @param bagagli the bagagli
     */
    public void setBagagli(int bagagli) {
        this.bagagli = bagagli;
    }

    /**
     * Gets tipo autoveicolo.
     *
     * @return the tipo autoveicolo
     */
    public String getTipoAutoveicolo() {
        return tipoAutoveicolo;
    }

    /**
     * Sets tipo autoveicolo.
     *
     * @param tipoAutoveicolo the tipo autoveicolo
     */
    public void setTipoAutoveicolo(String tipoAutoveicolo) {
        this.tipoAutoveicolo = tipoAutoveicolo;
    }

    /**
     * Is disabilita boolean.
     *
     * @return the boolean
     */
    public boolean isDisabilita() {
        return disabilita;
    }

    /**
     * Sets disabilita.
     *
     * @param disabilita the disabilita
     */
    public void setDisabilita(boolean disabilita) {
        this.disabilita = disabilita;
    }

    /**
     * Gets corsa.
     *
     * @return the corsa
     */
    public Corsa getCorsa() {
        return corsa;
    }

    /**
     * Sets corsa.
     *
     * @param corsa the corsa
     */
    public void setCorsa(Corsa corsa) {
        this.corsa = corsa;
    }

    /**
     * Gets cliente.
     *
     * @return the cliente
     */
    public Cliente getCliente() {
        return cliente;
    }

    /**
     * Sets cliente.
     *
     * @param cliente the cliente
     */
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
