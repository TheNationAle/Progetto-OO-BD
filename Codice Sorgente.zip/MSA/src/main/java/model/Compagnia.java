package model;

import java.lang.reflect.Array;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * The type Compagnia.
 */
public class Compagnia extends Utente{
    private String nome;
    private String telefono="";
    private String sitoWeb;
    private String social="";
    private float sovraprezzo_B=0;
    private float sovraprezzo_P=0;
    private ArrayList<Natante> ElencoNatanti = new ArrayList<Natante>();
    private ArrayList<Autoveicolo> ElencoAutoveicoli = new ArrayList<Autoveicolo>();


    /**
     * Instantiates a new Compagnia.
     *
     * @param email         the email
     * @param password      the password
     * @param nome          the nome
     * @param telefono      the telefono
     * @param sitoWeb       the sito web
     * @param social        the social
     * @param sovraprezzo_B the sovraprezzo b
     * @param sovraprezzo_P the sovraprezzo p
     */
    public Compagnia(String email, String password, String nome, String telefono, String sitoWeb,
                                                    String social, float sovraprezzo_B, float sovraprezzo_P) {
        super(email, password);
        this.nome = nome;
        this.telefono = telefono;
        this.sitoWeb = sitoWeb;
        this.social = social;
        this.sovraprezzo_B = sovraprezzo_B;
        this.sovraprezzo_P = sovraprezzo_P;
    }

    /**
     * Instantiates a new Compagnia.
     *
     * @param email    the email
     * @param password the password
     */
    public Compagnia(String email, String password) {
        super(email, password);
    }


    /**
     * Gets nome.
     *
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Sets nome.
     *
     * @param nome the nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Gets telefono.
     *
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Sets telefono.
     *
     * @param telefono the telefono
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Gets sito web.
     *
     * @return the sito web
     */
    public String getSitoWeb() {
        return sitoWeb;
    }

    /**
     * Sets sito web.
     *
     * @param sitoWeb the sito web
     */
    public void setSitoWeb(String sitoWeb) {
        this.sitoWeb = sitoWeb;
    }

    /**
     * Gets social.
     *
     * @return the social
     */
    public String getSocial() {
        return social;
    }

    /**
     * Sets social.
     *
     * @param social the social
     */
    public void setSocial(String social) {
        this.social = social;
    }

    /**
     * Gets sovraprezzo b.
     *
     * @return the sovraprezzo b
     */
    public float getSovraprezzo_B() {
        return sovraprezzo_B;
    }

    /**
     * Sets sovraprezzo b.
     *
     * @param sovraprezzo_B the sovraprezzo b
     */
    public void setSovraprezzo_B(float sovraprezzo_B) {
        this.sovraprezzo_B = sovraprezzo_B;
    }

    /**
     * Gets sovraprezzo p.
     *
     * @return the sovraprezzo p
     */
    public float getSovraprezzo_P() {
        return sovraprezzo_P;
    }

    /**
     * Sets sovraprezzo p.
     *
     * @param sovraprezzo_P the sovraprezzo p
     */
    public void setSovraprezzo_P(float sovraprezzo_P) {
        this.sovraprezzo_P = sovraprezzo_P;
    }

    /**
     * Gets elenco natanti.
     *
     * @return the elenco natanti
     */
    public ArrayList<Natante> getElencoNatanti() {
        return ElencoNatanti;
    }

    /**
     * Sets elenco natanti.
     *
     * @param elencoNatanti the elenco natanti
     */
    public void setElencoNatanti(ArrayList<Natante> elencoNatanti) {

        ElencoNatanti = elencoNatanti;
    }

    /**
     * Gets elenco autoveicoli.
     *
     * @return the elenco autoveicoli
     */
    public ArrayList<Autoveicolo> getElencoAutoveicoli() {
        return ElencoAutoveicoli;
    }

    /**
     * Sets elenco autoveicoli.
     *
     * @param elencoAutoveicoli the elenco autoveicoli
     */
    public void setElencoAutoveicoli(ArrayList<Autoveicolo> elencoAutoveicoli) {
        ElencoAutoveicoli = elencoAutoveicoli;
    }

    /**
     * Compra natente.
     *
     * @param natante the natante
     */
    void CompraNatente(Natante natante){
        ElencoNatanti.add(natante);
    }


    /**
     * Crea cadenza cadenza.
     *
     * @param s  the s
     * @param dI the d i
     * @param dF the d f
     * @return the cadenza
     */
    public Cadenza CreaCadenza(String s , Date dI, Date dF){
        Cadenza c = new Cadenza(s, dI, dF);
        return c;
    }

    /**
     * Funzione add natante.
     *
     * @param N the n
     */
    public void FunzioneAddNatante(Natante N){
    this.getElencoNatanti().add(N);
}


}
